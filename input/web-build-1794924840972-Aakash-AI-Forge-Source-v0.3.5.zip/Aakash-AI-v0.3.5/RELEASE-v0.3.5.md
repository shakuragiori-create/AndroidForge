# Aakash AI v0.3.5 source package

- Carries forward the Kotlin/Compose Android source and MP3 export implementation.
- Includes the user's 17 Nov 2026 M4A voice recording and a 24 kHz mono PCM WAV copy in `voice_dataset/aakash_first_sample/`.
- Increments Android `versionCode` to 12 and `versionName` to 0.3.5 for the next AndroidForge build.
- Keeps the supplied recording and its transcript-review placeholder together as a voice-data asset.

Important: this package does not contain a trained Aakash neural voice model or offline on-device neural inference. The existing Create workflow still uses the configured remote clone API and the bundled backend still references Swar. Do not describe this package as a completed offline voice-cloning app.
