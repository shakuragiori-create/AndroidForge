package com.aakashai.voice

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private val Blue = Color(0xFF2563EB)
private val DeepBlue = Color(0xFF1746B5)
private val PaleBlue = Color(0xFFEFF6FF)
private val Ink = Color(0xFF14213D)
private val Muted = Color(0xFF718096)
private val Canvas = Color(0xFFF6F8FC)
private val Border = Color(0xFFE6ECF5)
private val Green = Color(0xFF16A36A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AakashTheme {
                AakashApp(onGenerateSpeech = { text, referenceFile, referenceText, serverUrl, apiToken, onStatus ->
                    if (referenceFile == null) {
                        onStatus("Record your voice in My Voice and select that recording before generating a clone.")
                    } else if (serverUrl.isBlank()) {
                        onStatus("Connect the Aakash voice server in Settings first. Your voice recording is not sent anywhere until you generate speech.")
                    } else {
                        onStatus("Generating with your reference voice… keep the app open.")
                        CloneApiClient.generate(this, serverUrl, referenceFile, referenceText, text, apiToken) { result ->
                            runOnUiThread {
                                result.onSuccess { onStatus("Your cloned-voice audio is ready: ${it.name}. Open Library to play or export MP3.") }
                                    .onFailure { onStatus("Voice generation failed: ${it.message ?: "Unknown server error"}") }
                            }
                        }
                    }
                })
            }
        }
    }
}

@Composable
private fun AakashTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            onPrimary = Color.White,
            primaryContainer = PaleBlue,
            onPrimaryContainer = DeepBlue,
            secondary = Color(0xFF5B8DEF),
            background = Canvas,
            surface = Color.White,
            onSurface = Ink,
            onSurfaceVariant = Muted,
            outline = Border
        ),
        typography = Typography(),
        content = content
    )
}

private enum class Tab(val label: String) {
    HOME("Home"), CREATE("Create"), VOICES("My Voice"), LIBRARY("Library"), SETTINGS("Settings")
}

private data class RecordingItem(val file: File, val createdAt: Long)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AakashApp(onGenerateSpeech: (String, File?, String, String, String, (String) -> Unit) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedTab by remember { mutableStateOf(Tab.HOME) }
    var script by remember { mutableStateOf("नमस्कार! Aakash AI मा तपाईंलाई स्वागत छ।") }
    var isRecording by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Your personal voice studio is ready.") }
    var latestFile by remember { mutableStateOf<File?>(null) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var recordings by remember { mutableStateOf(listOf<RecordingItem>()) }
    var sampleTranscript by remember { mutableStateOf("नमस्कार, मेरो नाम आकाश हो। म आज आफ्नो आवाजको नमुना रेकर्ड गर्दैछु। म नेपाली भाषामा स्पष्ट र स्वाभाविक रूपमा बोल्ने अभ्यास गर्दैछु। कृपया मेरो आवाजको उतारचढाव, उच्चारण र बोल्ने गति ध्यानपूर्वक सुन्नुहोस्। मलाई प्रविधि, शिक्षा, व्यवसाय र दैनिक जीवनका विषयमा कुरा गर्न मन पर्छ। आजको दिन राम्रो रहोस्।") }
    var selectedVoiceFile by remember { mutableStateOf<File?>(null) }
    var selectedVoiceTranscript by remember { mutableStateOf("") }
    var serverUrl by remember { mutableStateOf(context.getSharedPreferences("aakash_ai", 0).getString("clone_server_url", "") ?: "") }
    var apiToken by remember { mutableStateOf(context.getSharedPreferences("aakash_ai", 0).getString("clone_api_token", "") ?: "") }

    fun refreshRecordings() {
        recordings = context.filesDir.listFiles()
            ?.filter { it.isFile && (it.name.endsWith(".m4a") || it.name.endsWith(".wav")) }
            ?.sortedByDescending { it.lastModified() }
            ?.map { RecordingItem(it, it.lastModified()) } ?: emptyList()
        if (selectedVoiceFile == null || selectedVoiceFile?.exists() != true) {
            val usable = recordings.firstOrNull { File(it.file.parentFile, it.file.nameWithoutExtension + ".txt").isFile }
            if (usable != null) {
                selectedVoiceFile = usable.file
                selectedVoiceTranscript = File(usable.file.parentFile, usable.file.nameWithoutExtension + ".txt").readText(Charsets.UTF_8)
            }
        }
    }
    LaunchedEffect(Unit) { refreshRecordings() }

    fun startRecording() {
        try {
            val file = File(context.filesDir, "aakash_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(128000)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            latestFile = file
            isRecording = true
            status = "Recording in progress… speak clearly and naturally."
        } catch (e: Exception) {
            status = "Could not start recording: ${e.localizedMessage ?: "Unknown error"}"
        }
    }

    fun stopRecording() {
        try {
            recorder?.stop()
            recorder?.release()
            recorder = null
            isRecording = false
            latestFile?.let { audio ->
                val transcriptFile = File(audio.parentFile, audio.nameWithoutExtension + ".txt")
                if (sampleTranscript.isNotBlank()) {
                    transcriptFile.writeText(sampleTranscript.trim(), Charsets.UTF_8)
                    selectedVoiceFile = audio
                    selectedVoiceTranscript = sampleTranscript.trim()
                }
            }
            refreshRecordings()
            status = if (sampleTranscript.isNotBlank()) "Recording and transcript saved. This sample is ready as your voice reference." else "Recording saved. Add the exact words you spoke before using it as a voice reference."
        } catch (_: Exception) {
            isRecording = false
            recorder?.release()
            recorder = null
            status = "Recording was too short or could not be saved. Try again."
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRecording() else status = "Microphone permission is required to record your voice."
    }

    var filePendingExport by remember { mutableStateOf<File?>(null) }
    var filePendingMp3 by remember { mutableStateOf<File?>(null) }
    val audioExport = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/*")
    ) { uri ->
        val source = filePendingExport
        if (uri != null && source != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output -> source.inputStream().use { it.copyTo(output) } }
                status = "Audio exported: ${source.name}"
            } catch (e: Exception) {
                status = "Audio export failed: ${e.localizedMessage ?: "storage error"}"
            }
        }
        filePendingExport = null
    }

    val mp3Export = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/mpeg")
    ) { uri ->
        val source = filePendingMp3
        if (uri != null && source != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    source.inputStream().use { it.copyTo(output) }
                } ?: error("Could not open the selected destination.")
                status = "MP3 exported successfully: ${source.name}"
            } catch (e: Exception) {
                status = "MP3 export failed: ${e.localizedMessage ?: "storage error"}"
            }
        }
        filePendingMp3?.delete()
        filePendingMp3 = null
    }

    val datasetExport = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    ZipOutputStream(output).use { zip ->
                        val manifest = StringBuilder("audio\ttranscript\n")
                        recordings.filter { it.file.extension.lowercase() == "m4a" }.forEach { item ->
                            val transcript = File(item.file.parentFile, item.file.nameWithoutExtension + ".txt")
                            zip.putNextEntry(ZipEntry("audio/${item.file.name}"))
                            item.file.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                            val text = if (transcript.exists()) transcript.readText(Charsets.UTF_8).replace("\t", " ").replace("\n", " ") else ""
                            if (transcript.exists()) {
                                zip.putNextEntry(ZipEntry("transcripts/${transcript.name}"))
                                transcript.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                            manifest.append("audio/").append(item.file.name).append("\t").append(text).append("\n")
                        }
                        zip.putNextEntry(ZipEntry("metadata.tsv"))
                        zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                        zip.putNextEntry(ZipEntry("README.txt"))
                        zip.write("Aakash AI voice dataset. Each audio recording should have an exact matching transcript. Record in a quiet room with consistent microphone distance. Review transcripts before model training.".toByteArray())
                        zip.closeEntry()
                    }
                }
                status = "Voice dataset exported. Keep this ZIP safe; it contains your voice recordings."
            } catch (e: Exception) {
                status = "Dataset export failed: ${e.localizedMessage ?: "storage error"}"
            }
        }
    }

    Scaffold(
        containerColor = Canvas,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                        Image(
                            painter = painterResource(R.drawable.aakash_logo_mark),
                            contentDescription = "Aakash AI logo",
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(13.dp))
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                            Text("Aakash AI", fontWeight = FontWeight.ExtraBold, color = Ink)
                            Text("YOUR VOICE • NEPALI AI", style = MaterialTheme.typography.labelSmall, color = Muted)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { selectedTab = Tab.SETTINGS }) {
                        Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Ink)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                Tab.values().forEach { tab ->
                    val icon = when (tab) {
                        Tab.HOME -> Icons.Rounded.Home
                        Tab.CREATE -> Icons.Rounded.AutoAwesome
                        Tab.VOICES -> Icons.Rounded.RecordVoiceOver
                        Tab.LIBRARY -> Icons.Rounded.LibraryMusic
                        Tab.SETTINGS -> Icons.Rounded.Settings
                    }
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(icon, contentDescription = tab.label) },
                        label = { Text(tab.label, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Blue,
                            selectedTextColor = Blue,
                            indicatorColor = PaleBlue,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = selectedTab,
            modifier = Modifier.padding(padding).fillMaxSize(),
            transitionSpec = {
                (fadeIn(tween(220)) + slideInHorizontally(
                    animationSpec = tween(280, easing = FastOutSlowInEasing),
                    initialOffsetX = { it / 14 }
                )).togetherWith(
                    fadeOut(tween(140)) + slideOutHorizontally(
                        animationSpec = tween(220, easing = FastOutSlowInEasing),
                        targetOffsetX = { -it / 18 }
                    )
                ).using(SizeTransform(clip = false))
            },
            label = "main_navigation"
        ) { tab ->
            when (tab) {
                Tab.HOME -> HomeScreen(
                    onCreate = { selectedTab = Tab.CREATE },
                    onRecord = { selectedTab = Tab.VOICES },
                    recordingCount = recordings.size,
                    cloneReady = selectedVoiceFile != null && selectedVoiceTranscript.isNotBlank() && serverUrl.startsWith("https://") && apiToken.isNotBlank(),
                    status = status
                )
                Tab.CREATE -> CreateScreen(
                    script = script,
                    onScriptChange = { script = it },
                    recordings = recordings.filter { File(it.file.parentFile, it.file.nameWithoutExtension + ".txt").isFile },
                    selectedVoiceFile = selectedVoiceFile,
                    selectedVoiceTranscript = selectedVoiceTranscript,
                    onSelectVoice = { file ->
                        selectedVoiceFile = file
                        selectedVoiceTranscript = File(file.parentFile, file.nameWithoutExtension + ".txt").takeIf { it.isFile }?.readText(Charsets.UTF_8).orEmpty()
                    },
                    serverUrl = serverUrl,
                    apiToken = apiToken,
                    onGenerate = { onGenerateSpeech(script, selectedVoiceFile, selectedVoiceTranscript, serverUrl, apiToken) { message -> status = message; refreshRecordings() } }
                )
                Tab.VOICES -> VoiceScreen(
                    isRecording = isRecording,
                    status = status,
                    latestFile = latestFile,
                    transcript = sampleTranscript,
                    onTranscriptChange = { sampleTranscript = it },
                    onExportDataset = { datasetExport.launch("AakashAI-voice-dataset.zip") },
                    onRecord = {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (granted) startRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onStop = { stopRecording() },
                    onPlay = { file ->
                        try {
                            player?.release()
                            player = MediaPlayer().apply {
                                setDataSource(file.absolutePath)
                                prepare()
                                start()
                            }
                            status = "Playing recording."
                        } catch (_: Exception) { status = "Unable to play this recording." }
                    }
                )
                Tab.LIBRARY -> LibraryScreen(
                    recordings = recordings,
                    onExport = { file -> filePendingExport = file; audioExport.launch(file.name) },
                    onExportMp3 = { source ->
                        status = "Converting ${source.name} to MP3…"
                        Thread {
                            val converted = File(context.cacheDir, "${source.nameWithoutExtension}_${System.currentTimeMillis()}.mp3")
                            try {
                                Mp3Converter.convert(source, converted, 128)
                                Handler(Looper.getMainLooper()).post {
                                    filePendingMp3 = converted
                                    status = "MP3 is ready. Choose where to save it."
                                    mp3Export.launch("${source.nameWithoutExtension}.mp3")
                                }
                            } catch (e: Exception) {
                                converted.delete()
                                Handler(Looper.getMainLooper()).post {
                                    status = "MP3 conversion failed: ${e.localizedMessage ?: "unsupported audio"}"
                                }
                            }
                        }.start()
                    },
                    onPlay = { file ->
                        try {
                            player?.release()
                            player = MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); start() }
                            status = "Playing recording."
                        } catch (_: Exception) { status = "Unable to play this recording." }
                    }
                )
                Tab.SETTINGS -> SettingsScreen(
                    serverUrl = serverUrl,
                    onServerUrlChange = {
                        serverUrl = it
                        context.getSharedPreferences("aakash_ai", 0).edit().putString("clone_server_url", it.trim()).apply()
                    },
                    apiToken = apiToken,
                    onApiTokenChange = {
                        apiToken = it
                        context.getSharedPreferences("aakash_ai", 0).edit().putString("clone_api_token", it.trim()).apply()
                    },
                    onTestConnection = { callback -> CloneApiClient.test(serverUrl.trim(), callback) }
                )
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try { recorder?.release() } catch (_: Exception) {}
            try { player?.release() } catch (_: Exception) {}
        }
    }
}

@Composable
private fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Canvas).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content
    )
}

@Composable
private fun HomeScreen(onCreate: () -> Unit, onRecord: () -> Unit, recordingCount: Int, cloneReady: Boolean, status: String) {
    PageColumn {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Good day 👋", style = MaterialTheme.typography.titleMedium, color = Muted)
            Text("Create something\nwith your voice.", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold, color = Ink)
        }
        Card(
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                Modifier.background(Brush.linearGradient(listOf(Color(0xFF3478F6), Color(0xFF1746B5))))
                    .padding(21.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Color.White.copy(alpha = .18f), shape = CircleShape) {
                            Icon(Icons.Rounded.Waves, null, tint = Color.White, modifier = Modifier.padding(10.dp).size(22.dp))
                        }
                        Spacer(Modifier.width(9.dp))
                        Text("YOUR PERSONAL VOICE", color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                    Text("Your words.\nYour voice. Your AI.", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("Build and use your own Nepali voice model.", color = Color.White.copy(alpha = .85f))
                    Button(
                        onClick = onCreate,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepBlue),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Create speech", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(7.dp))
                        Icon(Icons.Rounded.ArrowForward, null)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Audio files", recordingCount.toString(), Icons.Rounded.Mic, Modifier.weight(1f))
            StatCard("Clone setup", if (cloneReady) "Connected" else "Setup needed", Icons.Rounded.RecordVoiceOver, Modifier.weight(1f))
        }
        SectionTitle("Quick actions")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile("Record voice", "Create your voice reference", Icons.Rounded.Mic, onRecord, Modifier.weight(1f))
            ActionTile("Write a script", "Turn text to audio", Icons.Rounded.EditNote, onCreate, Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = Blue)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Project status", fontWeight = FontWeight.Bold, color = Ink)
                    Text(status, color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun CreateScreen(
    script: String,
    onScriptChange: (String) -> Unit,
    recordings: List<RecordingItem>,
    selectedVoiceFile: File?,
    selectedVoiceTranscript: String,
    onSelectVoice: (File) -> Unit,
    serverUrl: String,
    apiToken: String,
    onGenerate: () -> Unit
) {
    var showVoiceChoices by remember { mutableStateOf(false) }
    PageColumn {
        ScreenHeading("Create with my voice", "Turn your Nepali or English text into speech in your own voice.")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.TextFields, null, tint = Blue)
                    Spacer(Modifier.width(8.dp))
                    Text("YOUR SCRIPT", fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text("${script.length}/600", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
                OutlinedTextField(
                    value = script,
                    onValueChange = onScriptChange,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 170.dp),
                    placeholder = { Text("यहाँ नेपाली वा English text लेख्नुहोस्…") },
                    shape = RoundedCornerShape(15.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Blue, unfocusedBorderColor = Border)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(onClick = { onScriptChange(script + "\nनमस्कार! तपाईंलाई स्वागत छ।") }, label = { Text("Add sample") })
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { onScriptChange("") }) { Text("Clear") }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = PaleBlue), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.RecordVoiceOver, null, tint = Blue, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("MY CLONED VOICE", color = DeepBlue, fontWeight = FontWeight.ExtraBold)
                        Text(selectedVoiceFile?.name ?: "No reference recording selected", color = DeepBlue, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { showVoiceChoices = true }, enabled = recordings.isNotEmpty()) { Text("Change") }
                }
                if (selectedVoiceTranscript.isNotBlank()) {
                    Text("Reference transcript: ${selectedVoiceTranscript.take(140)}${if (selectedVoiceTranscript.length > 140) "…" else ""}", color = DeepBlue, style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("Go to My Voice, record 20–30 seconds, and save the exact words you speak. Select that recording here.", color = DeepBlue, style = MaterialTheme.typography.bodySmall)
                }
                DropdownMenu(expanded = showVoiceChoices, onDismissRequest = { showVoiceChoices = false }) {
                    recordings.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item.file.name, maxLines = 1) },
                            onClick = { onSelectVoice(item.file); showVoiceChoices = false },
                            leadingIcon = { Icon(Icons.Rounded.AudioFile, null) }
                        )
                    }
                }
            }
        }
        Button(
            onClick = onGenerate,
            enabled = script.isNotBlank() && script.length <= 600 && selectedVoiceFile != null && selectedVoiceTranscript.isNotBlank() && serverUrl.startsWith("https://") && apiToken.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Rounded.AutoAwesome, null)
            Spacer(Modifier.width(9.dp))
            Text("Generate with my cloned voice", fontWeight = FontWeight.Bold)
        }
        Text("Your reference voice is sent to the clone server you configure in Settings only when you tap Generate. The server returns audio that you can play and export as MP3. Internet is required for this server-based version.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun VoiceScreen(
    isRecording: Boolean,
    status: String,
    latestFile: File?,
    transcript: String,
    onTranscriptChange: (String) -> Unit,
    onExportDataset: () -> Unit,
    onRecord: () -> Unit,
    onStop: () -> Unit,
    onPlay: (File) -> Unit
) {
    PageColumn {
        ScreenHeading("My voice", "Record a voice sample to make speech sound like you.")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("EXACT RECORDING TRANSCRIPT", color = Ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                OutlinedTextField(
                    value = transcript,
                    onValueChange = onTranscriptChange,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                    placeholder = { Text("रेकर्ड गर्दा बोल्ने वाक्य यहाँ लेख्नुहोस्…") },
                    shape = RoundedCornerShape(14.dp)
                )
                Text("Record 20–30 seconds of your own voice in a quiet room. Read these words exactly. The transcript is sent with the recording so the model can learn how you sound.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.size(112.dp).clip(CircleShape).background(PaleBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (isRecording) Icons.Rounded.GraphicEq else Icons.Rounded.Mic, null, tint = Blue, modifier = Modifier.size(49.dp))
                }
                Text(if (isRecording) "Recording your voice…" else "Voice recording studio", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                Text(if (isRecording) "Read the text naturally. Avoid rushing." else "Use a quiet room and keep the phone at a steady distance.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                AnimatedVisibility(visible = isRecording) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Blue)
                }
                Button(
                    onClick = if (isRecording) onStop else onRecord,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = if (isRecording) ButtonDefaults.buttonColors(containerColor = Color(0xFFDC3545)) else ButtonDefaults.buttonColors()
                ) {
                    Icon(if (isRecording) Icons.Rounded.Stop else Icons.Rounded.FiberManualRecord, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isRecording) "Stop recording" else "Start recording")
                }
                Text(status, color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        SectionTitle("Recording checklist")
        ChecklistRow("Quiet room", "Avoid fans, traffic and background music")
        ChecklistRow("Consistent distance", "Keep the microphone in the same position")
        ChecklistRow("Natural delivery", "Speak clearly, not like a robot")
        latestFile?.let {
            OutlinedButton(onClick = { onPlay(it) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Play latest recording")
            }
        }
        OutlinedButton(onClick = onExportDataset, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.FolderZip, null); Spacer(Modifier.width(8.dp)); Text("Export voice dataset ZIP")
        }
        Text("This recording can be selected as your voice-cloning reference on the Create screen. Only record a voice you own or have permission to use.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun LibraryScreen(recordings: List<RecordingItem>, onExport: (File) -> Unit, onExportMp3: (File) -> Unit, onPlay: (File) -> Unit) {
    PageColumn {
        ScreenHeading("Audio library", "Your voice samples and generated speech, saved on this device.")
        if (recordings.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(25.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Rounded.LibraryMusic, null, tint = Blue, modifier = Modifier.size(42.dp))
                    Text("No recordings yet", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Your voice samples and generated cloned-voice audio will appear here.", color = Muted)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(recordings) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = PaleBlue, shape = RoundedCornerShape(12.dp)) {
                                Icon(Icons.Rounded.AudioFile, null, tint = Blue, modifier = Modifier.padding(11.dp))
                            }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Ink, fontWeight = FontWeight.SemiBold)
                                Text(SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date(item.createdAt)), color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { onExport(item.file) }) {
                                Icon(Icons.Rounded.FileDownload, contentDescription = "Export original audio", tint = Blue)
                            }
                            IconButton(onClick = { onExportMp3(item.file) }) {
                                Icon(Icons.Rounded.MusicNote, contentDescription = "Convert and export MP3", tint = DeepBlue)
                            }
                            IconButton(onClick = { onPlay(item.file) }) {
                                Icon(Icons.Rounded.PlayCircle, null, tint = Blue, modifier = Modifier.size(29.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    serverUrl: String,
    onServerUrlChange: (String) -> Unit,
    apiToken: String,
    onApiTokenChange: (String) -> Unit,
    onTestConnection: ((Result<String>) -> Unit) -> Unit
) {
    var connectionStatus by remember { mutableStateOf("Not tested") }
    var testing by remember { mutableStateOf(false) }
    PageColumn {
        ScreenHeading("Settings", "Connect your Nepali voice-cloning engine.")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Cloud, null, tint = Blue)
                    Spacer(Modifier.width(8.dp))
                    Text("VOICE CLONE SERVER", fontWeight = FontWeight.ExtraBold, color = Ink)
                }
                OutlinedTextField(
                    value = serverUrl,
                    onValueChange = onServerUrlChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("HTTPS server URL") },
                    placeholder = { Text("https://your-aakash-server.trycloudflare.com") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = apiToken,
                    onValueChange = onApiTokenChange,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Private server access token") },
                    placeholder = { Text("Paste the token printed by Colab") },
                    singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                )
                Button(
                    onClick = {
                        testing = true
                        connectionStatus = "Connecting…"
                        onTestConnection { result ->
                            testing = false
                            connectionStatus = result.fold({ it }, { "Connection failed: ${it.message}" })
                        }
                    },
                    enabled = serverUrl.startsWith("https://") && apiToken.isNotBlank() && !testing,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (testing) "Testing…" else "Test voice server") }
                Text(connectionStatus, color = if (connectionStatus.startsWith("Aakash voice server")) Green else Muted, style = MaterialTheme.typography.bodySmall)
                Text("The server runs the Nepali Swar/F5-TTS model. Paste both the temporary HTTPS URL and private token printed by Colab. Keep the token secret. Free GPU sessions can disconnect and are not guaranteed to stay online.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        SettingsRow(Icons.Rounded.Palette, "Appearance", "Blue & white theme", "Active")
        SettingsRow(Icons.Rounded.Storage, "Storage", "Recordings and generated audio stay on this phone", "Local")
        SettingsRow(Icons.Rounded.Security, "Privacy", "Reference audio is sent only to your configured server when generating", "Consent")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Aakash AI", fontWeight = FontWeight.ExtraBold, color = Ink)
                Text("Version 0.3.0 • Nepali voice cloning studio", color = Muted, style = MaterialTheme.typography.bodySmall)
                Text("Offline cloning is not included in this version; generation needs the configured GPU server. Your server token is stored in app-private preferences.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ScreenHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(subtitle, color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = Blue)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text(title, style = MaterialTheme.typography.bodySmall, color = Muted)
        }
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Surface(color = PaleBlue, shape = RoundedCornerShape(12.dp)) {
                Icon(icon, null, tint = Blue, modifier = Modifier.padding(9.dp))
            }
            Text(title, color = Ink, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ChecklistRow(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
        Icon(Icons.Rounded.CheckCircle, null, tint = Green)
        Column {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SettingsRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            Text(value, color = Blue, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
    }
}
