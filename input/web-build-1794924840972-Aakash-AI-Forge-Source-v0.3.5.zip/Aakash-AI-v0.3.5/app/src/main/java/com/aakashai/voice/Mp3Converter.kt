package com.aakashai.voice

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile

/** Converts app-generated PCM WAV and AAC/M4A recordings to a real MPEG Layer III file. */
object Mp3Converter {
    fun convert(input: File, output: File, bitrateKbps: Int = 128) {
        require(input.isFile && input.length() > 44) { "Audio file is empty or missing." }
        val decoded = if (input.extension.equals("wav", true)) readPcmWav(input) else decodeToPcm(input)
        try {
            encodePcm(decoded.first, decoded.second, decoded.third, output, bitrateKbps)
        } finally {
            decoded.first.delete()
        }
        require(output.isFile && output.length() > 128) { "MP3 encoding produced an empty file." }
    }

    // Returns temp PCM file, sample rate and channel count.
    private fun readPcmWav(file: File): Triple<File, Int, Int> {
        RandomAccessFile(file, "r").use { raf ->
            val riff = ByteArray(4); raf.readFully(riff)
            require(String(riff, Charsets.US_ASCII) == "RIFF") { "Unsupported WAV container." }
            raf.seek(8)
            val wave = ByteArray(4); raf.readFully(wave)
            require(String(wave, Charsets.US_ASCII) == "WAVE") { "Invalid WAV file." }
            var channels = 0; var sampleRate = 0; var bits = 0; var format = 0
            var dataOffset = -1L; var dataSize = 0L
            while (raf.filePointer + 8 <= raf.length()) {
                val idBytes = ByteArray(4); raf.readFully(idBytes)
                val id = String(idBytes, Charsets.US_ASCII)
                val size = readLeInt(raf).toLong() and 0xffffffffL
                val start = raf.filePointer
                when (id) {
                    "fmt " -> {
                        format = readLeShort(raf); channels = readLeShort(raf)
                        sampleRate = readLeInt(raf); raf.skipBytes(6)
                        bits = readLeShort(raf)
                    }
                    "data" -> { dataOffset = start; dataSize = size }
                }
                if (dataOffset >= 0 && format != 0) break
                raf.seek(start + size + (size and 1L))
            }
            require(format == 1 && bits == 16 && channels in 1..2 && sampleRate > 0 && dataOffset >= 0) {
                "Only 16-bit PCM WAV files (mono or stereo) can be converted."
            }
            val pcm = File.createTempFile("aakash_pcm_", ".raw", file.parentFile)
            raf.seek(dataOffset)
            FileOutputStream(pcm).use { out ->
                val buffer = ByteArray(64 * 1024)
                var remaining = minOf(dataSize, raf.length() - dataOffset)
                while (remaining > 0) {
                    val count = raf.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                    if (count < 0) break
                    out.write(buffer, 0, count); remaining -= count
                }
            }
            return Triple(pcm, sampleRate, channels)
        }
    }

    private fun decodeToPcm(file: File): Triple<File, Int, Int> {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        val pcm = File.createTempFile("aakash_decoded_", ".raw", file.parentFile)
        try {
            extractor.setDataSource(file.absolutePath)
            var track = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { track = i; inputFormat = f; break }
            }
            require(track >= 0 && inputFormat != null) { "No supported audio track found." }
            extractor.selectTrack(track)
            val mime = inputFormat!!.getString(MediaFormat.KEY_MIME)!!
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()
            var sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
            var inputDone = false; var outputDone = false
            val info = MediaCodec.BufferInfo()
            FileOutputStream(pcm).use { out ->
                var guard = 0
                while (!outputDone && guard++ < 200000) {
                    if (!inputDone) {
                        val index = codec.dequeueInputBuffer(10000)
                        if (index >= 0) {
                            val buffer = codec.getInputBuffer(index)!!
                            val size = extractor.readSampleData(buffer, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    when (val outIndex = codec.dequeueOutputBuffer(info, 10000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = codec.outputFormat
                            sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceIn(1, 2)
                            val pcmEncoding = if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) f.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                            require(pcmEncoding == 2) { "Audio decoder did not provide 16-bit PCM." }
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                        else -> if (outIndex >= 0) {
                            val buffer = codec.getOutputBuffer(outIndex)
                            if (buffer != null && info.size > 0) {
                                buffer.position(info.offset); buffer.limit(info.offset + info.size)
                                val bytes = ByteArray(info.size); buffer.get(bytes); out.write(bytes)
                            }
                            outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                            codec.releaseOutputBuffer(outIndex, false)
                        }
                    }
                }
                require(outputDone && pcm.length() > 0) { "Audio decoding did not finish." }
            }
            return Triple(pcm, sampleRate, channels)
        } catch (e: Exception) {
            pcm.delete()
            throw e
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            extractor.release()
        }
    }

    private fun encodePcm(pcmFile: File, sampleRate: Int, channels: Int, output: File, bitrate: Int) {
        require(sampleRate >= 8000 && channels in 1..2) { "Unsupported audio format." }
        val lame: AndroidLame = LameBuilder()
            .setInSampleRate(sampleRate)
            .setOutChannels(channels)
            .setOutBitrate(bitrate)
            .setOutSampleRate(sampleRate)
            .setQuality(3)
            .build()
        try {
            BufferedInputStream(FileInputStream(pcmFile)).use { input ->
                BufferedOutputStream(FileOutputStream(output)).use { out ->
                    val bytes = ByteArray(32 * 1024)
                    val mp3 = ByteArray(7200 + (bytes.size * 1.25).toInt())
                    var pendingByte = -1
                    var pendingShort: Short? = null
                    while (true) {
                        val count = input.read(bytes)
                        if (count < 0) break
                        val shorts = ShortArray((count + 1) / 2 + (if (pendingByte >= 0) 1 else 0) + (if (pendingShort != null) 1 else 0))
                        var p = 0
                        var i = 0
                        if (pendingByte >= 0 && count > 0) {
                            shorts[p++] = (pendingByte or ((bytes[0].toInt() and 0xff) shl 8)).toShort()
                            pendingByte = -1
                            i = 1
                        }
                        while (i + 1 < count) {
                            shorts[p++] = ((bytes[i].toInt() and 0xff) or (bytes[i + 1].toInt() shl 8)).toShort()
                            i += 2
                        }
                        if (i < count) pendingByte = bytes[i].toInt() and 0xff
                        var usable = p
                        if (pendingShort != null) {
                            val combined = ShortArray(p + 1)
                            combined[0] = pendingShort!!
                            System.arraycopy(shorts, 0, combined, 1, p)
                            System.arraycopy(combined, 0, shorts, 0, combined.size)
                            pendingShort = null
                            usable++
                        }
                        if (channels == 2 && usable % 2 != 0) {
                            pendingShort = shorts[usable - 1]
                            usable--
                        }
                        if (usable > 0) {
                            val sampleCountPerChannel = usable / channels
                            // TAndroidLame exposes separate left/right PCM arrays via encode().
                            // Mono audio is supplied to both inputs; stereo input is de-interleaved.
                            val n = if (channels == 1) {
                                lame.encode(shorts, shorts, sampleCountPerChannel, mp3)
                            } else {
                                val left = ShortArray(sampleCountPerChannel)
                                val right = ShortArray(sampleCountPerChannel)
                                var frame = 0
                                while (frame < sampleCountPerChannel) {
                                    left[frame] = shorts[frame * 2]
                                    right[frame] = shorts[frame * 2 + 1]
                                    frame++
                                }
                                lame.encode(left, right, sampleCountPerChannel, mp3)
                            }
                            if (n > 0) out.write(mp3, 0, n)
                        }
                    }
                    require(pendingByte < 0 && pendingShort == null) { "Audio PCM ended on an incomplete sample." }
                    val tail = ByteArray(7200)
                    val flushed = lame.flush(tail)
                    if (flushed > 0) out.write(tail, 0, flushed)
                }
            }
        } finally { lame.close() }
    }

    private fun readLeShort(raf: RandomAccessFile): Int = raf.readUnsignedByte() or (raf.readUnsignedByte() shl 8)
    private fun readLeInt(raf: RandomAccessFile): Int = raf.readUnsignedByte() or (raf.readUnsignedByte() shl 8) or (raf.readUnsignedByte() shl 16) or (raf.readUnsignedByte() shl 24)
}
