# Aakash AI v0.3.3 — build-fix package

The supplied AndroidForge logs report unresolved `apiToken` and `encodeBufferInterleaved` references. In the actual v0.3.2 source ZIP, `CreateScreen` already declares `apiToken: String`, and `Mp3Converter` already uses the separate-channel `lame.encode(left, right, ...)` method. The logs therefore appear to come from a different/older workspace snapshot.

This package bumps the app version to 0.3.3 and includes that source. The ZIP passes archive integrity checks. It has NOT been compiled by Gradle or tested on a phone. Run the existing AndroidForge workflow to verify the APK.

IMPORTANT: this is not offline neural voice cloning. The current app still calls `CloneApiClient` and requires a configured remote clone server and access token. No on-device neural TTS model/runtime is integrated.
