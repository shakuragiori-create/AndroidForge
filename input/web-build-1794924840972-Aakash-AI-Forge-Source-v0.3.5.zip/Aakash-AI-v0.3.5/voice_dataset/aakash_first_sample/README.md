# Aakash AI — first Nepali voice sample

Duration: 69.74 seconds. Original M4A is preserved; a 24 kHz mono PCM WAV copy is included.

Complete `transcript_needs_review.txt` with the exact spoken words before supervised training. This short sample is suitable for initial audio-quality checks and dataset preparation, not for training a high-quality voice clone from scratch.

No model has been trained and no offline neural inference engine is included. The existing Android project still calls a remote clone API; its bundled backend uses the Swar checkpoint, so it is not the requested custom offline Aakash engine.
