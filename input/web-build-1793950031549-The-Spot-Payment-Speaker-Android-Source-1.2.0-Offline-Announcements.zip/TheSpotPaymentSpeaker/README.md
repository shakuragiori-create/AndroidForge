# The Spot Payment Speaker — Android source 1.2.0

This source continues from the 1.1.0 Android companion and keeps the existing Spot connection endpoints and device-key security.

## 1.2.0 changes
- Local Fonepay announcement: a successful `SBL_Alert` / `Transaction success` / `Fonepay QR` notification with an amount and RRN is spoken on the phone immediately. Network access is not required for the voice announcement.
- eSewa notification detection: the app identifies notifications whose Android app label or package contains `eSewa`, stores recent title/message samples locally, and announces only incoming-payment wording with a recognised amount.
- Custom notification rule: configurable app/package text, optional notification-title text, required success keyword, and an announcement template supporting `{amount}` and `{rupees}`.
- Separate local switches: main Payment Speaker, Fonepay, eSewa and Custom.
- Local duplicate protection is stored on-device.
- Spot's master Payment Announcement setting is cached after a successful online status check. The local master and source switches are also applied.
- Fixed the literal `\\n` display in the How it Works text.
- WorkManager no longer delays or triggers speech; it is used only for the existing Fonepay record-forwarding workflow.

## Important integration boundary
The current Spot plugin endpoint `/wp-json/spot/v1/payment-notification` validates the existing SBL/Fonepay format. This Android update intentionally continues sending only Fonepay notifications to that endpoint. eSewa and custom notifications are announced locally but are **not yet synced to Spot's payment history**. A coordinated Spot plugin API extension is required before those sources can safely sync to the server. The existing Spot popup and endpoint are not changed by this Android source update.

## eSewa detection and verification
Android identifies the eSewa app by its installed app label or package name containing `eSewa`. The app captures the title and message of eSewa notifications in the local diagnostics area. It uses incoming-payment wording and an amount check to avoid announcing ordinary eSewa alerts. Notification formats can vary by eSewa app version and device; review the captured sample and test with a real small payment before operational use. Do not treat the notification as independent bank settlement verification.

## Offline operation
- The phone can announce only while it is powered on, Notification Access is enabled, and an offline-capable Nepali `ne-NP` TTS voice is installed.
- Connect the app to Spot while online at least once so the Spot master announcement state is cached. When offline, the last cached Spot master state is used. If the cached master state is OFF or has never been obtained, the app fails closed and does not speak.
- If the Spot master switch is changed while the phone is offline, the phone cannot know about that change until it reconnects. The on-device master/source switches work locally at all times.
- Fonepay records are queued with WorkManager and retried when connectivity returns. The existing endpoint remains authoritative for server-side duplicate protection and history.

## Build
Android Gradle Plugin 8.6.1, Kotlin 2.0.20, JDK 17, Android SDK Platform 35. Build variant: Auto. Force NDK Install: unchecked.

## Validation
A successful source archive is not the same as a successful Android build or live-device test. Compile with AndroidForge, install on the target Android phone, grant Notification Access, verify Nepali voice in airplane mode, and test real Fonepay and eSewa notifications. Review the eSewa diagnostic sample before enabling it for live payment use.
