package com.thespot.paymentspeaker

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var permissionStatus: TextView
    private lateinit var connectionStatus: TextView
    private lateinit var diagnosticsView: TextView
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshPermissionStatus()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xFFF5F7F5.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        content.addView(TextView(this).apply {
            text = "THE SPOT"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFF14543B.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = "PAYMENT SPEAKER"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF34443B.toInt())
            setPadding(0, 4, 0, 18)
        })
        content.addView(TextView(this).apply {
            text = "Payment announcements are processed on this phone first. Internet is used only for syncing supported payment records to Spot."
            textSize = 14f
            setTextColor(0xFF4B5563.toInt())
            setPadding(0, 0, 0, 18)
        })

        section(content, "ANNOUNCEMENT CONTROLS")
        addSwitch(content, "Payment Speaker", PaymentPrefs.master(this), PaymentPrefs::setMaster,
            "Main local switch. OFF stops all voice announcements.")
        addSwitch(content, "Fonepay Announcement", PaymentPrefs.fonepay(this), PaymentPrefs::setFonepay,
            "Successful SBL_Alert Fonepay QR notifications.")
        addSwitch(content, "eSewa Announcement", PaymentPrefs.esewa(this), PaymentPrefs::setEsewa,
            "Incoming eSewa payment notifications detected from the eSewa app.")
        addSwitch(content, "Custom Announcement", PaymentPrefs.custom(this), PaymentPrefs::setCustom,
            "Use your own app/title/message matching rule.")

        section(content, "CUSTOM NOTIFICATION RULE")
        val packageInput = field("App name or package contains", PaymentPrefs.customPackage(this))
        val titleRuleInput = field("Notification title contains (optional)", PaymentPrefs.customTitle(this))
        val keywordInput = field("Success keyword in message (required)", PaymentPrefs.customKeyword(this))
        val templateInput = field("Announcement text; use {amount}", PaymentPrefs.customTemplate(this))
        content.addView(packageInput)
        content.addView(titleRuleInput)
        content.addView(keywordInput)
        content.addView(templateInput)
        content.addView(actionButton("Save Custom Rule") {
            PaymentPrefs.saveCustom(this, packageInput.text.toString(), titleRuleInput.text.toString(),
                keywordInput.text.toString(), templateInput.text.toString())
            Toast.makeText(this, "Custom notification rule saved on this phone.", Toast.LENGTH_SHORT).show()
        })
        content.addView(TextView(this).apply {
            text = "Custom rules require a message keyword and a recognised amount (Rs, NPR or रु). Keep the keyword specific to a successful incoming payment."
            textSize = 12f
            setTextColor(0xFF66736B.toInt())
            setPadding(0, 4, 0, 12)
        })

        section(content, "SPOT CONNECTION")
        urlInput = field("Spot website URL (https://...)", SpotConfig.baseUrl(this))
        keyInput = field("Device key from Spot Settings", "")
        keyInput.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        content.addView(urlInput)
        content.addView(keyInput)
        content.addView(actionButton("Save Spot Connection") { saveConnection() })
        connectionStatus = statusText("Connection not checked")
        content.addView(connectionStatus)
        content.addView(actionButton("Check Spot Connection") { checkConnection() })

        section(content, "ANDROID PERMISSIONS")
        permissionStatus = statusText("Notification access status: checking…")
        content.addView(permissionStatus)
        content.addView(actionButton("Enable Notification Access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        content.addView(actionButton("Test Nepali Voice") {
            executor.execute {
                val ok = NepaliSpeech.speakBlocking(this, "पाँच सय रुपैयाँ भुक्तानी प्राप्त भयो।")
                runOnUiThread {
                    Toast.makeText(this,
                        if (ok) "Nepali voice test completed." else "Nepali voice is unavailable. Install offline Nepali voice data in your TTS engine.",
                        Toast.LENGTH_LONG).show()
                }
            }
        })

        section(content, "eSEWA NOTIFICATION DIAGNOSTICS")
        diagnosticsView = statusText("")
        content.addView(diagnosticsView)
        content.addView(actionButton("Refresh eSewa Samples") { refreshDiagnostics() })
        content.addView(actionButton("Clear Diagnostic Samples") {
            PaymentPrefs.clearDiagnostics(this)
            refreshDiagnostics()
        })
        content.addView(TextView(this).apply {
            text = "Only eSewa-app notification title/message samples are stored locally for parser diagnostics. Review samples before relying on eSewa announcements."
            textSize = 12f
            setTextColor(0xFF66736B.toInt())
            setPadding(0, 4, 0, 12)
        })

        section(content, "HOW IT WORKS")
        content.addView(TextView(this).apply {
            text = "1. Admin assigns Sandesh's phone in Spot Settings and provides the device key.\n2. Save the HTTPS Spot URL and device key here.\n3. Enable Notification Access for The Spot Payment Listener.\n4. Turn on the announcement sources you want.\n5. Connect once while online so the app can cache the Spot master announcement setting.\n6. Payment voice runs locally; Fonepay records sync through the existing Spot endpoint when internet returns."
            textSize = 13f
            setTextColor(0xFF59645D.toInt())
            setPadding(0, 4, 0, 0)
        })

        scroll.addView(content)
        page.addView(scroll)
        setContentView(page)
        refreshDiagnostics()
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFF14543B.toInt())
            setPadding(0, 20, 0, 8)
        })
    }

    private fun addSwitch(parent: LinearLayout, label: String, checked: Boolean,
                          save: (android.content.Context, Boolean) -> Unit, description: String) {
        parent.addView(Switch(this).apply {
            text = label
            isChecked = checked
            textSize = 15f
            setTextColor(0xFF26352D.toInt())
            setOnCheckedChangeListener { _, value -> save(this@MainActivity, value) }
        })
        parent.addView(TextView(this).apply {
            text = description
            textSize = 12f
            setTextColor(0xFF66736B.toInt())
            setPadding(0, 0, 0, 8)
        })
    }

    private fun field(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText
        setSingleLine(false)
        textSize = 14f
        setText(value)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun statusText(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(0xFF53615A.toInt())
        setPadding(4, 8, 4, 8)
    }

    private fun saveConnection() {
        val base = urlInput.text.toString().trim().trimEnd('/')
        val key = keyInput.text.toString().trim().ifBlank { SpotConfig.deviceKey(this) }
        if (!base.startsWith("https://") || key.isBlank()) {
            Toast.makeText(this, "Enter the HTTPS Spot website URL and device key.", Toast.LENGTH_LONG).show()
            return
        }
        SpotConfig.setBaseUrl(this, base)
        SpotConfig.setDeviceKey(this, key)
        keyInput.setText("")
        Toast.makeText(this, "Spot connection saved securely on this phone.", Toast.LENGTH_SHORT).show()
        checkConnection()
    }

    private fun checkConnection() {
        val base = SpotConfig.baseUrl(this)
        val key = SpotConfig.deviceKey(this)
        if (!base.startsWith("https://") || key.isBlank()) {
            connectionStatus.text = "Save the Spot URL and device key first."
            return
        }
        connectionStatus.text = "Checking secure connection…"
        executor.execute {
            try {
                val result = SpotApi.status(base, key)
                val body = result.body
                if (result.code in 200..299 && body.optBoolean("ok", false) && body.has("announcement_enabled")) {
                    SpotConfig.setRemoteMaster(this, body.optBoolean("announcement_enabled", false))
                }
                runOnUiThread {
                    connectionStatus.text = if (result.code in 200..299 && body.optBoolean("ok", false)) {
                        val enabled = body.optBoolean("announcement_enabled", false)
                        if (enabled) "Connected to Spot · Spot master announcement is ON."
                        else "Connected to Spot · Spot master announcement is OFF. Turn it ON in the Spot Profile Menu."
                    } else {
                        "Connection failed (${result.code}): ${body.optString("message", "Check the assigned device and key.")}"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { connectionStatus.text = "Connection error: ${e.message ?: "Check internet and HTTPS URL."}" }
            }
        }
    }

    private fun refreshPermissionStatus() {
        val component = ComponentName(this, SpotNotificationListener::class.java)
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(component.flattenToString()) == true
        permissionStatus.text = if (enabled) "Notification Access: ENABLED"
        else "Notification Access: NOT ENABLED — enable it below."
    }

    private fun refreshDiagnostics() {
        if (!::diagnosticsView.isInitialized) return
        val items = PaymentPrefs.diagnostics(this)
        diagnosticsView.text = if (items.isEmpty()) "No eSewa notification samples captured yet. When an eSewa notification arrives, its title and message will appear here."
        else items.take(8).joinToString("\n\n────────────\n\n")
    }

    override fun onResume() {
        super.onResume()
        if (::permissionStatus.isInitialized) refreshPermissionStatus()
        if (::connectionStatus.isInitialized && SpotConfig.isConfigured(this)) checkConnection()
        refreshDiagnostics()
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
