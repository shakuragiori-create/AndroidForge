package com.thespot.paymentspeaker

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class SpotNotificationListener : NotificationListenerService() {
    private val processor = Executors.newSingleThreadExecutor()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        processor.execute {
            try {
                val alert = PaymentParser.inspect(this, sbn) ?: return@execute
                if (!PaymentPrefs.canAnnounce(this, alert.source)) return@execute
                if (PaymentPrefs.alreadyHandled(this, alert.dedupeId)) return@execute

                // Speak on-device immediately. Network status never blocks this announcement.
                NepaliSpeech.speakBlocking(this, alert.announcement)

                // Keep the existing Spot endpoint limited to its supported Fonepay/SBL format.
                // eSewa and custom alerts are not posted to the Fonepay-only endpoint.
                if (alert.source == PaymentSource.FONEPAY && SpotConfig.isConfigured(this)) {
                    val data = Data.Builder()
                        .putString("base_url", SpotConfig.baseUrl(this))
                        .putString("device_key", SpotConfig.deviceKey(this))
                        .putString("sender", alert.title)
                        .putString("message", alert.body.take(2000))
                        .putString("notification_id", "${alert.packageName}:${alert.transactionId}")
                        .build()
                    val request = OneTimeWorkRequestBuilder<PaymentForwardWorker>()
                        .setInputData(data)
                        .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 20, TimeUnit.SECONDS)
                        .build()
                    WorkManager.getInstance(applicationContext).enqueueUniqueWork(
                        "spot-payment-${alert.transactionId}", ExistingWorkPolicy.KEEP, request
                    )
                }
            } catch (_: Exception) {
                // Notification listener must remain alive if a single notification is malformed.
            }
        }
    }

    override fun onDestroy() {
        processor.shutdown()
        super.onDestroy()
    }
}
