package com.thespot.paymentspeaker

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object SpotApi {
    data class ApiResult(val code: Int, val body: JSONObject)

    fun status(baseUrl: String, deviceKey: String): ApiResult {
        return request(
            "$baseUrl/wp-json/spot/v1/payment-device-status",
            "GET",
            deviceKey,
            null
        )
    }

    fun forward(baseUrl: String, deviceKey: String, sender: String, message: String, notificationId: String): ApiResult {
        val payload = JSONObject()
            .put("sender", sender)
            .put("message", message)
            .put("notification_id", notificationId)
        return request(
            "$baseUrl/wp-json/spot/v1/payment-notification",
            "POST",
            deviceKey,
            payload.toString()
        )
    }

    private fun request(endpoint: String, method: String, deviceKey: String, body: String?): ApiResult {
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 15000
                readTimeout = 20000
                instanceFollowRedirects = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Authorization", "Bearer $deviceKey")
                // Fallback header for hosting setups that strip Authorization.
                setRequestProperty("X-Spot-Device-Key", deviceKey)
                if (body != null) {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
            }
            if (body != null) {
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: "{}"
            val json = try { JSONObject(raw) } catch (_: Exception) { JSONObject().put("message", raw.take(500)) }
            return ApiResult(code, json)
        } finally {
            connection?.disconnect()
        }
    }
}
