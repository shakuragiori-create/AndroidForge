package com.thespot.paymentspeaker

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class PaymentForwardWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val base = inputData.getString("base_url") ?: return Result.failure()
        val key = inputData.getString("device_key") ?: return Result.failure()
        val sender = inputData.getString("sender") ?: return Result.failure()
        val message = inputData.getString("message") ?: return Result.failure()
        val notificationId = inputData.getString("notification_id") ?: return Result.failure()

        return try {
            val response = SpotApi.forward(base, key, sender, message, notificationId)
            if (response.body.has("announcement_enabled")) {
                SpotConfig.setRemoteMaster(applicationContext, response.body.optBoolean("announcement_enabled", false))
            }
            when {
                response.code in 200..299 -> Result.success()
                response.code in 400..499 -> Result.failure()
                else -> Result.retry()
            }
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
