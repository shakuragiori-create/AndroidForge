package com.thespot.paymentspeaker

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object SpotConfig {
    private const val PREFS = "spot_payment_config"
    private const val SECRET_ALIAS = "TheSpotPaymentSpeakerKey"

    private fun prefs(context: android.content.Context) =
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)

    fun baseUrl(context: android.content.Context): String =
        prefs(context).getString("base_url", "") ?: ""

    fun setBaseUrl(context: android.content.Context, value: String) {
        prefs(context).edit().putString("base_url", value.trim().trimEnd('/')).apply()
    }

    fun setDeviceKey(context: android.content.Context, value: String) {
        val key = getOrCreateKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + encrypted
        prefs(context).edit().putString("device_key", Base64.encodeToString(combined, Base64.NO_WRAP)).apply()
    }

    fun deviceKey(context: android.content.Context): String {
        return try {
            val encoded = prefs(context).getString("device_key", null) ?: return ""
            val combined = Base64.decode(encoded, Base64.NO_WRAP)
            if (combined.size <= 12) return ""
            val iv = combined.copyOfRange(0, 12)
            val cipherText = combined.copyOfRange(12, combined.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    fun setRemoteMaster(context: android.content.Context, enabled: Boolean) {
        prefs(context).edit().putBoolean("remote_gate_known", true).putBoolean("remote_master_enabled", enabled).apply()
    }

    fun remoteGateKnown(context: android.content.Context): Boolean =
        prefs(context).getBoolean("remote_gate_known", false)

    fun remoteMasterEnabled(context: android.content.Context): Boolean =
        prefs(context).getBoolean("remote_master_enabled", false)

    fun isConfigured(context: android.content.Context): Boolean =
        baseUrl(context).startsWith("https://") && deviceKey(context).isNotBlank()

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = store.getKey(SECRET_ALIAS, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                SECRET_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
