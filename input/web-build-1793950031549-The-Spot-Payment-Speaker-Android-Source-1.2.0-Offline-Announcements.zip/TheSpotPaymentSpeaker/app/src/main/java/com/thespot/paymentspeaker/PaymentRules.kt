package com.thespot.paymentspeaker

import android.content.Context
import android.content.pm.PackageManager
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.security.MessageDigest
import java.util.Locale

enum class PaymentSource { FONEPAY, ESEWA, CUSTOM }

data class PaymentAlert(
    val source: PaymentSource,
    val appLabel: String,
    val packageName: String,
    val title: String,
    val body: String,
    val amount: String,
    val transactionId: String,
    val dedupeId: String,
    val announcement: String
)

object PaymentPrefs {
    private const val PREFS = "spot_payment_rules"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun master(c: Context) = p(c).getBoolean("master_on", true)
    fun setMaster(c: Context, v: Boolean) { p(c).edit().putBoolean("master_on", v).apply() }
    fun fonepay(c: Context) = p(c).getBoolean("fonepay_on", true)
    fun setFonepay(c: Context, v: Boolean) { p(c).edit().putBoolean("fonepay_on", v).apply() }
    fun esewa(c: Context) = p(c).getBoolean("esewa_on", true)
    fun setEsewa(c: Context, v: Boolean) { p(c).edit().putBoolean("esewa_on", v).apply() }
    fun custom(c: Context) = p(c).getBoolean("custom_on", false)
    fun setCustom(c: Context, v: Boolean) { p(c).edit().putBoolean("custom_on", v).apply() }

    fun customPackage(c: Context) = p(c).getString("custom_package", "") ?: ""
    fun customTitle(c: Context) = p(c).getString("custom_title", "") ?: ""
    fun customKeyword(c: Context) = p(c).getString("custom_keyword", "") ?: ""
    fun customTemplate(c: Context) = p(c).getString("custom_template", "भुक्तानी प्राप्त भयो {amount} रुपैयाँ।") ?: ""
    fun saveCustom(c: Context, packageText: String, title: String, keyword: String, template: String) {
        p(c).edit()
            .putString("custom_package", packageText.trim())
            .putString("custom_title", title.trim())
            .putString("custom_keyword", keyword.trim())
            .putString("custom_template", template.trim())
            .apply()
    }

    fun canAnnounce(c: Context, source: PaymentSource): Boolean {
        if (!master(c) || !SpotConfig.remoteGateKnown(c) || !SpotConfig.remoteMasterEnabled(c)) return false
        return when (source) {
            PaymentSource.FONEPAY -> fonepay(c)
            PaymentSource.ESEWA -> esewa(c)
            PaymentSource.CUSTOM -> custom(c)
        }
    }

    fun alreadyHandled(c: Context, id: String): Boolean {
        val prefs = p(c)
        val set = prefs.getStringSet("handled_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        if (id in set) return true
        set.add(id)
        while (set.size > 300) set.remove(set.first())
        prefs.edit().putStringSet("handled_ids", set).apply()
        return false
    }

    fun addDiagnostic(c: Context, app: String, pkg: String, title: String, body: String) {
        val prefs = p(c)
        val arr = try { JSONArray(prefs.getString("diagnostics", "[]")) } catch (_: Exception) { JSONArray() }
        val item = JSONObject()
            .put("app", app.take(100))
            .put("package", pkg.take(180))
            .put("title", title.take(180))
            .put("body", body.take(420))
            .put("time", System.currentTimeMillis())
        val next = JSONArray()
        next.put(item)
        for (i in 0 until minOf(arr.length(), 19)) next.put(arr.getJSONObject(i))
        prefs.edit().putString("diagnostics", next.toString()).apply()
    }

    fun diagnostics(c: Context): List<String> {
        val arr = try { JSONArray(p(c).getString("diagnostics", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            "${o.optString("app")} · ${o.optString("title")}\n${o.optString("body")}"
        }
    }

    fun clearDiagnostics(c: Context) { p(c).edit().putString("diagnostics", "[]").apply() }
}

object PaymentParser {
    private val amountRegex = Regex("""(?i)(?:NPR|Rs\.?|रु\.?)\s*[:.]?\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)""")
    private val rrnRegex = Regex("""(?i)\bRRN\s*[:#-]?\s*([A-Za-z0-9]+)""")
    private val refRegex = Regex("""(?i)\b(?:transaction|txn|reference|ref)\s*(?:id|no\.?|number)?\s*[:#-]?\s*([A-Za-z0-9-]{5,})""")

    fun inspect(context: Context, sbn: StatusBarNotification): PaymentAlert? {
        val extras = sbn.notification.extras ?: return null
        val title = (extras.getCharSequence("android.title") ?: "").toString().trim()
        val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val normal = extras.getCharSequence("android.text")?.toString().orEmpty()
        val lines = extras.getCharSequenceArray("android.textLines")?.joinToString(" ") { it.toString() }.orEmpty()
        val body = (big.ifBlank { normal.ifBlank { lines } }).trim()
        if (title.isBlank() && body.isBlank()) return null

        val pm = context.packageManager
        val appLabel = try {
            val app = pm.getApplicationInfo(sbn.packageName, 0)
            pm.getApplicationLabel(app).toString()
        } catch (_: Exception) { sbn.packageName }

        val lower = (title + " " + body).lowercase(Locale.ROOT)
        val amount = amountRegex.find(title + " " + body)?.groupValues?.getOrNull(1) ?: return diagnosticIfEsewa(context, appLabel, sbn.packageName, title, body)
        val isFonepay = title.equals("SBL_Alert", true) &&
            lower.contains("transaction success") && lower.contains("fonepay qr")
        if (isFonepay) {
            val rrn = rrnRegex.find(body)?.groupValues?.getOrNull(1) ?: return null
            val id = "fonepay:${rrn.lowercase(Locale.ROOT)}"
            return PaymentAlert(PaymentSource.FONEPAY, appLabel, sbn.packageName, title, body,
                amount, rrn, id, NepaliAmountSpeech.paymentText(amount))
        }

        val isEsewaApp = sbn.packageName.contains("esewa", true) || appLabel.contains("esewa", true)
        if (isEsewaApp) {
            PaymentPrefs.addDiagnostic(context, appLabel, sbn.packageName, title, body)
            val incoming = listOf("payment received", "received payment", "you received", "received rs",
                "received npr", "money received", "credited", "रकम प्राप्त", "भुक्तानी प्राप्त")
                .any { lower.contains(it) }
            if (!incoming) return null
            val ref = refRegex.find(title + " " + body)?.groupValues?.getOrNull(1)
                ?: fallbackId(sbn, title, body)
            return PaymentAlert(PaymentSource.ESEWA, appLabel, sbn.packageName, title, body,
                amount, ref, "esewa:$ref", NepaliAmountSpeech.paymentText(amount))
        }

        if (PaymentPrefs.custom(context)) {
            val packageRule = PaymentPrefs.customPackage(context)
            val titleRule = PaymentPrefs.customTitle(context)
            val keyword = PaymentPrefs.customKeyword(context)
            val matches = (packageRule.isBlank() || sbn.packageName.contains(packageRule, true) || appLabel.contains(packageRule, true)) &&
                (titleRule.isBlank() || title.contains(titleRule, true)) &&
                keyword.isNotBlank() && lower.contains(keyword.lowercase(Locale.ROOT))
            if (matches) {
                val ref = refRegex.find(title + " " + body)?.groupValues?.getOrNull(1)
                    ?: fallbackId(sbn, title, body)
                val amountText = NepaliAmountSpeech.formatAmount(amount)
                val template = PaymentPrefs.customTemplate(context).ifBlank { "भुक्तानी प्राप्त भयो {amount} रुपैयाँ।" }
                val spoken = template.replace("{amount}", amountText).replace("{rupees}", NepaliAmountSpeech.words(amount))
                return PaymentAlert(PaymentSource.CUSTOM, appLabel, sbn.packageName, title, body,
                    amount, ref, "custom:$ref", spoken)
            }
        }
        return null
    }

    private fun diagnosticIfEsewa(c: Context, app: String, pkg: String, title: String, body: String): PaymentAlert? {
        if (pkg.contains("esewa", true) || app.contains("esewa", true)) {
            PaymentPrefs.addDiagnostic(c, app, pkg, title, body)
        }
        return null
    }

    private fun fallbackId(sbn: StatusBarNotification, title: String, body: String): String {
        val raw = "${sbn.packageName}|${title.trim()}|${body.trim()}|${sbn.postTime / 60000}"
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
            .take(16).joinToString("") { "%02x".format(it) }
    }
}

object NepaliAmountSpeech {
    private val ones = listOf("शून्य","एक","दुई","तीन","चार","पाँच","छ","सात","आठ","नौ","दश","एघार","बाह्र","तेह्र","चौध","पन्ध्र","सोह्र","सत्र","अठार","उन्नाइस")
    private val tens = listOf("","","बीस","तीस","चालीस","पचास","साठी","सत्तरी","असी","नब्बे")
    fun words(n: Long): String {
        if (n < 0) return "माइनस " + words(-n)
        if (n < 20) return ones[n.toInt()]
        if (n < 100) return tens[(n / 10).toInt()] + if (n % 10 == 0L) "" else " " + ones[(n % 10).toInt()]
        if (n < 1000) return words(n / 100) + " सय" + if (n % 100 == 0L) "" else " " + words(n % 100)
        val groups = listOf(10000000L to "करोड", 100000L to "लाख", 1000L to "हजार")
        for ((size, label) in groups) if (n >= size) {
            val q = n / size
            val r = n % size
            return words(q) + " " + label + if (r == 0L) "" else " " + words(r)
        }
        return n.toString()
    }
    fun words(value: String): String = try { words(BigDecimal(value.replace(",", "")).toLong()) } catch (_: Exception) { value }
    fun formatAmount(value: String): String = try {
        BigDecimal(value.replace(",", "")).stripTrailingZeros().toPlainString()
    } catch (_: Exception) { value }
    fun paymentText(value: String): String {
        return try {
            val amount = BigDecimal(value.replace(",", ""))
            val rupees = amount.toLong()
            val paisa = amount.remainder(BigDecimal.ONE).movePointRight(2).abs().toInt()
            val part = if (paisa > 0) " ${words(paisa.toLong())} पैसा" else ""
            "${words(rupees)} रुपैयाँ$part भुक्तानी प्राप्त भयो।"
        } catch (_: Exception) { "भुक्तानी प्राप्त भयो।" }
    }
}
