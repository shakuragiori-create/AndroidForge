package com.thespot.paymentspeaker

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object NepaliSpeech {
    fun speakBlocking(context: Context, text: String): Boolean {
        if (text.isBlank()) return false
        val ready = CountDownLatch(1)
        val finished = CountDownLatch(1)
        val supported = AtomicBoolean(false)
        var engine: TextToSpeech? = null

        Handler(Looper.getMainLooper()).post {
            engine = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val tts = engine
                    if (tts != null) {
                        val availability = tts.isLanguageAvailable(Locale("ne", "NP"))
                        if (availability >= TextToSpeech.LANG_AVAILABLE &&
                            tts.setLanguage(Locale("ne", "NP")) >= TextToSpeech.LANG_AVAILABLE
                        ) {
                            supported.set(true)
                            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                                override fun onStart(utteranceId: String?) {}
                                override fun onDone(utteranceId: String?) { finished.countDown() }
                                @Deprecated("Deprecated in Java")
                                override fun onError(utteranceId: String?) { finished.countDown() }
                                override fun onError(utteranceId: String?, errorCode: Int) { finished.countDown() }
                            })
                            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "spot-payment-${System.currentTimeMillis()}")
                        }
                    }
                }
                ready.countDown()
            }
        }

        val initialized = ready.await(12, TimeUnit.SECONDS)
        if (!initialized || !supported.get()) {
            Handler(Looper.getMainLooper()).post { engine?.shutdown() }
            return false
        }
        val spoke = finished.await(45, TimeUnit.SECONDS)
        Handler(Looper.getMainLooper()).post { engine?.shutdown() }
        return spoke
    }
}
