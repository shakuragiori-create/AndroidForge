# Aakash AI voice-clone server (Colab GPU)

This backend uses the **official Swar Nepali voice-cloning pipeline** from `Aarjan/swar`, including its enrollment frontend and voice synthesis code. It does not simply call a generic English TTS API. The app sends a reference recording, its transcript, and the requested text; the backend enrolls/caches that voice profile and generates a WAV.

## Start it from an Android phone

1. Download `Aakash-AI-Clone-Backend.zip` from this source package.
2. Open `AakashAI_Clone_Server_Colab.ipynb` in Google Colab using your phone browser. Choose **Runtime → Change runtime type → T4 GPU** if a free GPU is offered. Free GPU access is not guaranteed.
3. Run the first cell and upload `Aakash-AI-Clone-Backend.zip` when prompted. Run the remaining cells. The notebook downloads the official Swar repository/model assets (about 3.2 GB) and starts the backend.
4. Copy the `https://....trycloudflare.com` address and the private token printed by Colab.
5. In Aakash AI → Settings, paste both values and tap **Test voice server**. The status must say the server is connected and ready.
6. In My Voice, record 20–30 seconds of your own speech. Enter and save the exact transcript. In Create, select that recording, enter up to 600 characters of text, and generate.
7. Open Library to play the generated WAV or tap the MP3 icon to convert and save an MP3.

Keep the Colab notebook running while generating. The free session and temporary URL/token expire when Colab disconnects or restarts. Start a new session and update both values when that happens.

## API

- `GET /health` returns `{"ready":true}` after the Swar pipeline is loaded.
- `POST /v1/clone` accepts multipart fields `audio`, `ref_text`, and `text`, requires `Authorization: Bearer <token>`, and returns a WAV file.
- Input text is limited to 600 characters and reference audio to 35 MB.

## Important limitations

- The neural model runs on the Colab GPU server, not locally on the phone. This version is not offline voice cloning. Recording, library playback, file storage, and MP3 conversion are local.
- The backend uses Swar's own enrollment pipeline (Kriti-based voice preparation) and caches the resulting voice profile for the current Colab session. The transcript is saved alongside the profile; the upstream enrollment pipeline performs its own speech recognition while preparing the voice.
- Colab free GPU availability and session duration are not guaranteed. This is not a permanent always-on server.
- The temporary Cloudflare tunnel is public HTTPS protected by a random bearer token. Do not share either the URL or token. The selected audio and target text are sent to that session when Generate is pressed.
- Only clone your own voice or a voice for which you have explicit permission.

## Model and licensing

Swar source code is MIT licensed; its published model weights are CC BY-SA 4.0. Review the model card and comply with attribution/share-alike requirements before redistribution. The model is downloaded from Hugging Face at startup and is not bundled in the Android source ZIP.
