"""Aakash AI API backed by Naamche Labs' official Swar Nepali voice-cloning pipeline.
Run on a GPU runtime such as Google Colab. The Android client sends a reference clip
and text; this service enrolls/caches that voice and synthesizes requested speech.
"""
from __future__ import annotations

import hashlib
import os
import secrets
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask
from huggingface_hub import snapshot_download

MODEL_REPO = os.getenv("AAKASH_MODEL_REPO", "Aarjan/swar")
MAX_TEXT_CHARS = 600  # official Swar cloner UI limit
VOICE_CACHE = Path(os.getenv("AAKASH_VOICE_CACHE", "/content/aakash_ai_voice_profiles"))
VOICE_CACHE.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="Aakash AI Voice Clone API", version="0.3.0")
_cloner = None
_model_error: Optional[str] = None
_model_lock = threading.Lock()
_generation_lock = threading.Lock()


def load_model():
    """Load the actual Swar pipeline (including its Kriti enrollment frontend)."""
    global _cloner, _model_error
    with _model_lock:
        if _cloner is not None:
            return _cloner
        try:
            repo_dir = Path(snapshot_download(repo_id=MODEL_REPO))
            app_dir = repo_dir / "app"
            required = [app_dir / "pipeline", app_dir / "tools", app_dir / "frontend", repo_dir / "podvoices_ema.pt", repo_dir / "vocab.txt"]
            missing = [str(p) for p in required if not p.exists()]
            if missing:
                raise RuntimeError("Swar model package is incomplete: " + ", ".join(missing))

            # Match the upstream Swar Space configuration. Import must happen only
            # after the model paths and frontend environment variables are set.
            import sys
            sys.path[:0] = [str(app_dir / "pipeline"), str(app_dir / "tools"), str(app_dir)]
            os.environ.setdefault("F5_CKPT", str(repo_dir / "podvoices_ema.pt"))
            english_ckpt = repo_dir / "swar_v6_ema.pt"
            if english_ckpt.exists():
                os.environ.setdefault("F5_EN_CKPT", str(english_ckpt))
            os.environ.setdefault("F5_VOCAB", str(repo_dir / "vocab.txt"))
            os.environ.setdefault("KRITI_ONNX", str(repo_dir / "kriti_onnx"))
            os.environ.setdefault("KRITI_PY", "/nonexistent")
            os.environ.setdefault("CONFORMER_PY", "/nonexistent")
            os.environ.setdefault("PRESETS_DIR", str(repo_dir / "presets"))
            os.environ.setdefault("BILINGUAL", "0")

            import autoclone  # type: ignore
            _cloner = autoclone
            _model_error = None
            return _cloner
        except Exception as exc:
            _model_error = f"{type(exc).__name__}: {exc}"
            raise


@app.on_event("startup")
def startup():
    try:
        load_model()
        print("Aakash AI: official Swar voice-cloning pipeline is ready")
    except Exception as exc:
        print(f"Aakash AI model failed to load: {exc}")


@app.get("/health")
def health():
    return {"ready": _cloner is not None, "model": MODEL_REPO, "error": _model_error}


@app.post("/v1/clone")
async def clone_voice(
    audio: UploadFile = File(...),
    ref_text: str = Form(...),
    text: str = Form(...),
    authorization: Optional[str] = Header(default=None),
):
    expected_token = os.getenv("AAKASH_API_TOKEN", "")
    supplied_token = authorization.removeprefix("Bearer ").strip() if authorization else ""
    if not expected_token or not secrets.compare_digest(supplied_token, expected_token):
        raise HTTPException(status_code=401, detail="Missing or invalid Aakash AI server token.")
    if _cloner is None:
        raise HTTPException(status_code=503, detail=f"Voice model is not ready: {_model_error or 'still loading'}")
    if not text.strip() or len(text) > MAX_TEXT_CHARS:
        raise HTTPException(status_code=400, detail=f"Text must contain 1–{MAX_TEXT_CHARS} characters.")
    if not ref_text.strip():
        raise HTTPException(status_code=400, detail="Enter the exact words spoken in your reference recording.")

    suffix = Path(audio.filename or "reference.m4a").suffix.lower()
    if suffix not in {".m4a", ".mp4", ".wav", ".aac", ".mp3", ".ogg", ".flac"}:
        raise HTTPException(status_code=415, detail="Unsupported reference audio format.")

    tmp = tempfile.mkdtemp(prefix="aakash_clone_request_")
    source = Path(tmp) / f"reference{suffix}"
    reference_wav = Path(tmp) / "reference_converted.wav"
    output_wav = Path(tmp) / "aakash_clone.wav"
    data = await audio.read()
    if not data or len(data) > 35 * 1024 * 1024:
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(status_code=413, detail="Reference audio is empty or larger than 35 MB.")
    source.write_bytes(data)
    convert = subprocess.run(
        ["ffmpeg", "-y", "-i", str(source), "-vn", "-ac", "1", "-ar", "24000", "-c:a", "pcm_s16le", str(reference_wav)],
        capture_output=True,
        text=True,
    )
    if convert.returncode != 0 or not reference_wav.exists():
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(status_code=422, detail="Could not decode the reference recording. " + (convert.stderr[-800:] if convert.stderr else "Please record again or use WAV/M4A."))

    # The voice is enrolled once per unique recording and reused for later text.
    # Keep only the derived voice profile on the Colab session disk; the request
    # upload is deleted after the response has been sent.
    voice_id = hashlib.sha256(reference_wav.read_bytes()).hexdigest()[:12]
    voice_dir = VOICE_CACHE / voice_id
    try:
        with _generation_lock:
            if not (voice_dir / "voice.json").exists():
                _cloner.enroll(str(voice_dir), [str(reference_wav)], one_speaker=True)
                (voice_dir / "reference_transcript.txt").write_text(ref_text.strip(), encoding="utf-8")
            result = _cloner.say_long(str(voice_dir), text.strip(), str(output_wav), takes=4)
        if not output_wav.exists() or output_wav.stat().st_size < 1024:
            raise RuntimeError(f"Swar did not produce an audio file. Result: {result}")
    except Exception as exc:
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(status_code=500, detail=f"Swar voice generation failed: {type(exc).__name__}: {exc}") from exc

    return FileResponse(
        str(output_wav),
        media_type="audio/wav",
        filename="aakash_ai_clone.wav",
        background=BackgroundTask(lambda: shutil.rmtree(tmp, ignore_errors=True)),
    )
