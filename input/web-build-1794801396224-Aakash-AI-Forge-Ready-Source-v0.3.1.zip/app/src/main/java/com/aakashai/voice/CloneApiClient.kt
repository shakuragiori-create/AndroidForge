package com.aakashai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

/** Sends a user's consented reference recording and text to their configured Aakash AI clone server. */
object CloneApiClient {
    fun generate(
        context: Context,
        baseUrl: String,
        referenceAudio: File,
        referenceText: String,
        text: String,
        apiToken: String,
        onComplete: (Result<File>) -> Unit
    ) {
        thread(name = "aakash-voice-clone") {
            try {
                require(baseUrl.startsWith("https://", true)) { "Use a secure HTTPS clone-server URL." }
                require(apiToken.isNotBlank()) { "Enter the server access token from the Colab cell." }
                require(referenceAudio.isFile && referenceAudio.length() > 1024) { "The selected reference recording is missing or empty." }
                require(referenceText.isNotBlank()) { "Add the exact transcript spoken in your reference recording." }
                require(text.isNotBlank() && text.length <= 600) { "Enter up to 600 characters of text." }
                val boundary = "AakashAI-${UUID.randomUUID()}"
                val endpoint = baseUrl.trimEnd('/') + "/v1/clone"
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 30_000
                    readTimeout = 300_000
                    doOutput = true
                    setChunkedStreamingMode(64 * 1024)
                    setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                    setRequestProperty("Accept", "audio/wav")
                    setRequestProperty("Authorization", "Bearer $apiToken")
                }
                try {
                    BufferedOutputStream(connection.outputStream).use { out ->
                        fun field(name: String, value: String) {
                            out.write("--$boundary\r\n".toByteArray())
                            out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
                            out.write(value.toByteArray(Charsets.UTF_8))
                            out.write("\r\n".toByteArray())
                        }
                        field("ref_text", referenceText)
                        field("text", text)
                        val mime = if (referenceAudio.extension.equals("wav", true)) "audio/wav" else "audio/mp4"
                        out.write("--$boundary\r\n".toByteArray())
                        out.write("Content-Disposition: form-data; name=\"audio\"; filename=\"reference.${referenceAudio.extension}\"\r\n".toByteArray())
                        out.write("Content-Type: $mime\r\n\r\n".toByteArray())
                        BufferedInputStream(referenceAudio.inputStream()).use { it.copyTo(out) }
                        out.write("\r\n--$boundary--\r\n".toByteArray())
                        out.flush()
                    }
                    val code = connection.responseCode
                    if (code !in 200..299) {
                        val detail = try { connection.errorStream?.bufferedReader()?.use { it.readText() } } catch (_: Exception) { null }
                        error("Clone server error $code${detail?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ". Check the server status."}")
                    }
                    val contentType = connection.contentType.orEmpty()
                    require(contentType.contains("audio", true) || contentType.contains("octet-stream", true)) {
                        "The server did not return an audio file. Check that the Aakash clone backend is running."
                    }
                    val output = File(context.filesDir, "aakash_clone_${System.currentTimeMillis()}.wav")
                    connection.inputStream.use { input -> File(output.absolutePath).outputStream().use { input.copyTo(it) } }
                    require(output.length() > 1024) { "The clone server returned an empty audio file." }
                    onComplete(Result.success(output))
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                onComplete(Result.failure(e))
            }
        }
    }

    fun test(baseUrl: String, onComplete: (Result<String>) -> Unit) {
        thread(name = "aakash-clone-health") {
            try {
                require(baseUrl.startsWith("https://", true)) { "Enter a secure HTTPS server URL." }
                val connection = (URL(baseUrl.trimEnd('/') + "/health").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12_000
                    readTimeout = 12_000
                }
                try {
                    val code = connection.responseCode
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    require(code in 200..299 && body.contains("\"ready\":true")) {
                        "Server responded, but the voice model is not ready."
                    }
                    Handler(Looper.getMainLooper()).post { onComplete(Result.success("Aakash voice server is connected and ready.")) }
                } finally { connection.disconnect() }
            } catch (e: Exception) { Handler(Looper.getMainLooper()).post { onComplete(Result.failure(e)) } }
        }
    }
}
