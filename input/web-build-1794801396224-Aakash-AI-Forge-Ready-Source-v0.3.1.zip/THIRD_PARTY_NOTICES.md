# Third-party notices

## Swar — Nepali voice cloning model

- Project: https://github.com/Naamche-Labs/swar
- Model: https://huggingface.co/Aarjan/swar
- Source code license: MIT
- Model weights license: Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
- The model is not bundled in this Android package. The optional backend downloads it from Hugging Face when started. If you redistribute model weights or derivative weights, comply with the model card's license, attribution, and share-alike terms.

## F5-TTS

- Project: https://github.com/SWivid/F5-TTS
- Used by the backend as the inference library for the Swar checkpoint. Review its upstream license and dependencies before redistributing a hosted backend.

## Android LAME encoder

- Dependency: `com.github.kaushik-naik:TAndroidLame`
- The current Android project documents its GPL-3.0 obligations in this file and in `docs/MP3_EXPORT.md`. Comply with the library's license when distributing the APK/source.
