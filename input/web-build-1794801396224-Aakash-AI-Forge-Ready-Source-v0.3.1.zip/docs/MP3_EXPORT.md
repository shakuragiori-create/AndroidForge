# MP3 export in v0.2.4

The Library now shows a separate MP3 action beside the original-file export and playback actions.

- Supported sources: app-generated 16-bit PCM WAV and app-recorded AAC/M4A.
- WAV conversion: reads the RIFF `fmt ` and `data` chunks and accepts PCM 16-bit mono/stereo.
- M4A conversion: decodes the audio track to PCM using Android `MediaExtractor` and `MediaCodec`.
- Encoding: LAME, 128 kbps, performed locally on the phone.
- Destination: Android's Create Document picker, suggested filename `<source>.mp3`.
- The original recording/generated WAV is never overwritten.

The conversion runs off the UI thread. Unsupported or malformed source audio reports an error rather than creating a renamed non-MP3 file. The actual APK still needs build and device verification, including MP3 playback on the target phone.
