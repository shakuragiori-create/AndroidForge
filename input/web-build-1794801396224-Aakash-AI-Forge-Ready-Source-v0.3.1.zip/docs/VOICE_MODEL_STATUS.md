# Voice cloning status — v0.3.0

A real reference-conditioned Nepali voice-cloning path is now wired into the app:

1. Record your own voice in My Voice and save the exact transcript.
2. Select that recording in Create and enter the text to speak.
3. The Android app sends the recording, transcript, and target text over HTTPS to the server URL configured in Settings, using a private bearer token.
4. The included FastAPI server loads the open Swar Nepali F5-TTS checkpoint and returns generated WAV audio.
5. The app stores the WAV locally; Library can play it and convert it to MP3.

## What is not offline

The F5-TTS model currently runs on a Colab GPU server. The Android app does not yet bundle an on-device model or run neural voice cloning offline. The temporary free Colab runtime can disconnect, and GPU availability is not guaranteed. The Android client requires an active server session and Internet access for generation.

## Model choice and licence

The backend uses the `Aarjan/swar` Nepali model checkpoint (`podvoices_ema.pt`) and vocabulary (`vocab.txt`) with the F5-TTS Base API. The published Swar model supports Nepali, English, and mixed speech and performs reference-audio voice cloning. Its code is MIT; its weights are CC BY-SA 4.0. See `THIRD_PARTY_NOTICES.md` and the upstream model card.

## Validation still required

The Android source has not yet been built by AndroidForge or tested on the user's Samsung device. The Colab model load/inference path has not been executed in this environment. Therefore this release is an implemented integration source, not a claim of a verified APK. The first AndroidForge build and one real 20–30 second voice sample are needed for end-to-end verification.

## MP3

Generated audio is returned as WAV. The Android Library's MP3 action uses the existing local LAME encoder to convert supported WAV/M4A input and saves the MP3 through Android's document picker. Test the actual encoder on-device before production distribution.
