# Aakash AI v0.3.1

## Android manifest merger fix

The TAndroidLame dependency declares `android:allowBackup` and `android:label` in its library manifest. The app manifest now explicitly declares `tools:replace="android:allowBackup,android:label"`, preserving Aakash AI's own `allowBackup=false` and `label=Aakash AI` values.

## Version

- `versionCode`: 8
- `versionName`: 0.3.1
- Java/Kotlin toolchain: 17 (unchanged)

## Scope and verification

This release fixes the exact manifest-merger failure recorded in AndroidForge logs (3). XML parsing, required manifest directives, Gradle version metadata, and ZIP integrity are checked. A complete Android SDK build and real-device voice-generation test have not been run in this environment.
