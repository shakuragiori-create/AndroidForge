#!/usr/bin/env python3
"""Prepare an Aakash AI voice-dataset ZIP for a later Nepali TTS training run.

Input ZIP layout from the Android app:
  audio/*.m4a
  transcripts/*.txt
  metadata.tsv (audio path<TAB>exact transcript)

Requires ffmpeg on PATH. Produces Piper-style wav/metadata.csv files.
This script prepares data only; it does not train a voice model.
"""
import argparse
import csv
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset_zip", type=Path)
    parser.add_argument("--output", type=Path, default=Path("aakash_training_data"))
    args = parser.parse_args()
    if not args.dataset_zip.is_file():
        sys.exit(f"Dataset ZIP not found: {args.dataset_zip}")
    if shutil.which("ffmpeg") is None:
        sys.exit("ffmpeg is required. Install it before preparing M4A recordings.")
    work = args.output / "source"
    wav_dir = args.output / "wav"
    work.mkdir(parents=True, exist_ok=True)
    wav_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.dataset_zip) as zf:
        zf.extractall(work)
    manifest = work / "metadata.tsv"
    if not manifest.exists():
        sys.exit("metadata.tsv missing. Export the ZIP from Aakash AI v0.2.3 or later.")
    rows = []
    with manifest.open(encoding="utf-8") as f:
        next(f, None)
        for line_no, line in enumerate(f, 2):
            parts = line.rstrip("\n").split("\t", 1)
            if len(parts) != 2 or not parts[1].strip():
                print(f"Skipping row {line_no}: transcript missing")
                continue
            rel_audio, transcript = parts
            src = work / rel_audio
            if not src.is_file():
                print(f"Skipping row {line_no}: audio missing: {rel_audio}")
                continue
            out_name = f"sample_{len(rows)+1:05d}.wav"
            dst = wav_dir / out_name
            cmd = ["ffmpeg", "-y", "-i", str(src), "-ac", "1", "-ar", "22050", "-sample_fmt", "s16", str(dst)]
            subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            rows.append((out_name, transcript.strip()))
    if not rows:
        sys.exit("No usable audio/transcript pairs found.")
    with (args.output / "metadata.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f, delimiter="|", quoting=csv.QUOTE_MINIMAL)
        writer.writerows(rows)
    print(f"Prepared {len(rows)} paired samples in {args.output.resolve()}")
    print("Review every transcript and listen to every WAV before training.")
    print("This is dataset preparation only; no model has been trained.")

if __name__ == "__main__":
    main()
