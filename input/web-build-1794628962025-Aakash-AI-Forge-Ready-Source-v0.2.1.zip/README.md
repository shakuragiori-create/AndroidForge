# Aakash AI — Forge-ready Android source (UI v0.2.0)

A native Kotlin + Jetpack Compose Android project with a polished blue-and-white interface and animated navigation.

## Included in this build
- Modern blue-and-white visual theme.
- Five animated navigation destinations: Home, Create, My Voice, Library, Settings.
- Animated screen transitions when switching navigation destinations.
- Home dashboard, status cards and quick actions.
- Nepali/English script editor.
- Microphone permission and local M4A/AAC voice recording.
- Playback of the latest recording and recordings in the local library.
- Local app-private storage.
- GitHub Actions workflow to build a debug APK from a phone.

## Important functional status
This is a UI + recording foundation, not a completed Nepali voice-cloning engine.
- AI TTS generation is intentionally not activated.
- No personal voice model is bundled.
- Dataset export, transcript alignment, training, ONNX inference and MP3 export remain to be implemented and tested.
- The app does not upload recordings to a server.

## Import / build
This is a standard Android Gradle project. Import the project root (the folder containing `settings.gradle.kts`) into Android Studio or a compatible Android project importer/Forge workflow.

If using GitHub from Android:
1. Create a repository named `AakashAI`.
2. Upload all files and folders from this ZIP to the repository root.
3. Open Actions and run `Build Aakash AI APK`.
4. Download the `Aakash-AI-debug-apk` artifact from the completed workflow run.
5. Extract the artifact ZIP and install the APK on your Android device.

## Recording advice
- Record in a quiet room with a stable microphone distance.
- Speak naturally and clearly.
- Use one sentence or short utterance per recording for future dataset alignment.
- Keep the exact Devanagari transcript for each recording.
- Keep original recordings backed up.

## Technical stack
- Kotlin
- Jetpack Compose
- Material 3
- Compose Animation
- Android MediaRecorder / MediaPlayer
\n\n### Build compatibility fix in v0.2.1\n\nJava compilation and Kotlin compilation are both configured for JVM 17 (`compileOptions` and Kotlin `jvmToolchain(17)`) to prevent the JVM-target mismatch reported by AndroidForge. The source has been updated, but this package has not been compiled or device-tested in this environment.\n