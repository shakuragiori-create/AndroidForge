# The Spot Payment Speaker — complete Android companion source (1.1.0)

This is the Android companion source intended to work with the coordinated The Spot WordPress plugin update 3.9.19.

## What it does
- Uses Android Notification Access only; it does not request SMS inbox or call-log permissions.
- Processes notifications only when the title is `SBL_Alert` and the text contains `Transaction success`, `Fonepay QR`, a valid `Rs.` amount, and an `RRN` reference.
- Sends the matching alert over HTTPS to the existing Spot REST endpoint `/wp-json/spot/v1/payment-notification`.
- Authenticates using the device key created by Spot Settings. The key is encrypted at rest using Android Keystore AES/GCM.
- Uses WorkManager with retry/backoff for temporary network failures and a unique work name based on RRN to prevent repeat processing on the phone.
- Speaks the Nepali phrase returned by Spot only when the server confirms a new payment and the assigned user's Spot Profile Menu toggle is ON.
- Does not speak duplicates, unrelated messages, rejected requests, or payments when the Spot toggle is OFF.
- Includes a connection-status check and Nepali TTS test button.

## Required coordinated Spot plugin
Install the matching `restaurantpro-manager-plugin-spot-payment-speaker-3.9.19-android-companion.zip` before using this app. The plugin adds the authenticated `GET /wp-json/spot/v1/payment-device-status` check endpoint and updates the Settings instructions to refer to this Android app. The existing payment POST endpoint, profile toggle, history, duplicate detection and panel toast remain in place.

## Setup
1. In Spot Panel → Settings → Branding & Business, assign Sandesh's staff account as the Registered Payment Device User. Save the form so the device key exists.
2. Install this app on Sandesh's Android phone.
3. Enter the HTTPS Spot site root URL and paste the Android Companion Device Key shown in Spot Settings. Tap Save, then Check Spot Connection.
4. Tap Enable Notification Access and enable **The Spot Payment Listener** in Android Settings.
5. Tap Test Nepali Voice. If Nepali is not available, install/update a TTS engine and its Nepali voice data in Android settings / Google Speech Services, then test again.
6. In Sandesh's Spot PWA Profile Menu, turn **Payment Announcement** ON. Turning it OFF stops speech without disconnecting the device.

## Supported SMS notification pattern
Example:
`Transaction success for Rs.500.0 from 974****338 via Fonepay QR for RRN 66210951FysM.`

Only the notification title `SBL_Alert` and matching successful Fonepay QR message is accepted. This app does not claim to verify a bank settlement; it relays the payment notification that the bank app exposed.

## Security and operational notes
- The device key is a bearer secret. Keep it private; regenerate it in Spot Settings if the phone is lost or the key is exposed.
- Use HTTPS only. Redirects are not followed when sending the key.
- Android may pause listeners due to OEM battery restrictions. Exempt the app from battery optimization if notifications are delayed, and test on the actual phone.
- Nepali speech requires an installed Android TTS engine that supports Nepali (`ne-NP`). The app intentionally does not silently substitute Hindi or another language.
- The source project must still be compiled by AndroidForge. A successful compile is not proof of live-site connectivity or physical-device operation; perform the checklist above before relying on it for payments.

## Build
Android Gradle Plugin 8.6.1, Kotlin 2.0.20, JDK 17, Android SDK Platform 35. Build variant: Auto. Force NDK Install: unchecked.
