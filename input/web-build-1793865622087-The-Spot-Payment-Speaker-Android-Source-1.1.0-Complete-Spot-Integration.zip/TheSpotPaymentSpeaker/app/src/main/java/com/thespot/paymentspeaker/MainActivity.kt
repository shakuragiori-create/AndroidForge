package com.thespot.paymentspeaker

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var permissionStatus: TextView
    private lateinit var connectionStatus: TextView
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshPermissionStatus()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xFFF5F7F5.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply {
            text = "THE SPOT"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFF14543B.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = "PAYMENT SPEAKER"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF34443B.toInt())
            setPadding(0, 4, 0, 22)
        })
        content.addView(TextView(this).apply {
            text = "Connect this phone to the payment device registered in your Spot Panel. Only successful SBL_Alert Fonepay QR payment notifications are processed."
            textSize = 14f
            setTextColor(0xFF4B5563.toInt())
            setPadding(0, 0, 0, 18)
        })

        urlInput = EditText(this).apply {
            hint = "Spot website URL (https://...)"
            setSingleLine(true)
            textSize = 15f
            setText(SpotConfig.baseUrl(this@MainActivity))
        }
        keyInput = EditText(this).apply {
            hint = "Device key from Spot Settings"
            setSingleLine(true)
            textSize = 15f
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        content.addView(urlInput)
        content.addView(keyInput)

        content.addView(actionButton("Save Spot Connection") { saveConnection() })
        connectionStatus = statusText("Connection not checked")
        content.addView(connectionStatus)
        content.addView(actionButton("Check Spot Connection") { checkConnection() })

        permissionStatus = statusText("Notification access status: checking…")
        content.addView(permissionStatus)
        content.addView(actionButton("Enable Notification Access") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        content.addView(actionButton("Test Nepali Voice") {
            executor.execute {
                val ok = NepaliSpeech.speakBlocking(this, "पाँच सय रुपैयाँ भुक्तानी प्राप्त भयो।")
                runOnUiThread {
                    Toast.makeText(
                        this,
                        if (ok) "Nepali voice test completed." else "Nepali voice is unavailable in the installed TTS engine. Install Nepali voice data or update your speech engine.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        })
        content.addView(TextView(this).apply {
            text = "How it works\\n1. Admin assigns this phone's staff account in Spot Settings.\\n2. Save the HTTPS site URL and device key here.\\n3. Enable Notification Access for The Spot Payment Listener.\\n4. Sandesh turns Payment Announcement ON in the Spot Profile Menu.\\n5. Matching payment alerts are sent securely to Spot; the phone speaks only when that toggle is ON."
            textSize = 13f
            setTextColor(0xFF59645D.toInt())
            setPadding(0, 18, 0, 0)
        })

        scroll.addView(content)
        page.addView(scroll)
        setContentView(page)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun statusText(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(0xFF53615A.toInt())
        setPadding(4, 8, 4, 8)
    }

    private fun saveConnection() {
        val base = urlInput.text.toString().trim().trimEnd('/')
        val key = keyInput.text.toString().trim().ifBlank { SpotConfig.deviceKey(this) }
        if (!base.startsWith("https://") || key.isBlank()) {
            Toast.makeText(this, "Enter the HTTPS Spot website URL and device key.", Toast.LENGTH_LONG).show()
            return
        }
        SpotConfig.setBaseUrl(this, base)
        SpotConfig.setDeviceKey(this, key)
        keyInput.setText("")
        Toast.makeText(this, "Spot connection saved securely on this phone.", Toast.LENGTH_SHORT).show()
        checkConnection()
    }

    private fun checkConnection() {
        val base = SpotConfig.baseUrl(this)
        val key = SpotConfig.deviceKey(this)
        if (!base.startsWith("https://") || key.isBlank()) {
            connectionStatus.text = "Save the Spot URL and device key first."
            return
        }
        connectionStatus.text = "Checking secure connection…"
        executor.execute {
            try {
                val result = SpotApi.status(base, key)
                val body = result.body
                runOnUiThread {
                    if (result.code in 200..299 && body.optBoolean("ok", false)) {
                        val enabled = body.optBoolean("announcement_enabled", false)
                        connectionStatus.text = if (enabled) {
                            "Connected to Spot · Payment Announcement is ON in the Spot Profile Menu."
                        } else {
                            "Connected to Spot · Turn Payment Announcement ON in the Spot Profile Menu when ready."
                        }
                    } else {
                        connectionStatus.text = "Connection failed (${result.code}): ${body.optString("message", "Check the assigned device and key.")}"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { connectionStatus.text = "Connection error: ${e.message ?: "Check internet and HTTPS URL."}" }
            }
        }
    }

    private fun refreshPermissionStatus() {
        val component = ComponentName(this, SpotNotificationListener::class.java)
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(component.flattenToString()) == true
        permissionStatus.text = if (enabled) {
            "Notification Access: ENABLED"
        } else {
            "Notification Access: NOT ENABLED — enable it below."
        }
    }

    override fun onResume() {
        super.onResume()
        if (::permissionStatus.isInitialized) refreshPermissionStatus()
        if (::connectionStatus.isInitialized && SpotConfig.isConfigured(this)) checkConnection()
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
