package com.thespot.paymentspeaker

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject

class PaymentForwardWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val base = inputData.getString("base_url") ?: return Result.failure()
        val key = inputData.getString("device_key") ?: return Result.failure()
        val sender = inputData.getString("sender") ?: return Result.failure()
        val message = inputData.getString("message") ?: return Result.failure()
        val notificationId = inputData.getString("notification_id") ?: return Result.failure()

        return try {
            val response = SpotApi.forward(base, key, sender, message, notificationId)
            when {
                response.code in 200..299 -> {
                    val body = response.body
                    val duplicate = body.optBoolean("duplicate", false)
                    val enabled = body.optBoolean("announcement_enabled", false)
                    val announcement = body.optString("announcement_text", "")
                    if (!duplicate && enabled && announcement.isNotBlank()) {
                        // Payment is already safely stored on the server. Speak only when
                        // the Spot Profile Menu toggle is ON for the assigned device user.
                        NepaliSpeech.speakBlocking(applicationContext, announcement)
                    }
                    Result.success()
                }
                response.code in 400..499 -> Result.failure()
                else -> Result.retry()
            }
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
