package com.thespot.paymentspeaker

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class SpotNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: return
        val sender = (extras.getCharSequence("android.title") ?: "").toString().trim()
        if (!sender.equals("SBL_Alert", ignoreCase = true)) return

        val body = buildString {
            val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
            val normal = extras.getCharSequence("android.text")?.toString().orEmpty()
            val lines = extras.getCharSequenceArray("android.textLines")
                ?.joinToString(" ") { it.toString() }.orEmpty()
            append(if (big.isNotBlank()) big else normal.ifBlank { lines })
        }.trim()

        // Restrict processing to the bank's successful Fonepay QR transaction alert.
        if (!body.contains("Transaction success", ignoreCase = true)) return
        if (!body.contains("Fonepay QR", ignoreCase = true)) return
        if (!Regex("""\bRs\.?\s*[0-9][0-9,]*(?:\.[0-9]{1,2})?""", RegexOption.IGNORE_CASE).containsMatchIn(body)) return
        val rrnMatch = Regex("""\bRRN\s+([A-Za-z0-9]+)""", RegexOption.IGNORE_CASE).find(body) ?: return
        val rrn = rrnMatch.groupValues[1]

        if (!SpotConfig.isConfigured(this)) return
        val base = SpotConfig.baseUrl(this)
        val key = SpotConfig.deviceKey(this)
        val data = Data.Builder()
            .putString("base_url", base)
            .putString("device_key", key)
            .putString("sender", sender)
            .putString("message", body.take(2000))
            .putString("notification_id", "${sbn.packageName}:$rrn")
            .build()

        val request = OneTimeWorkRequestBuilder<PaymentForwardWorker>()
            .setInputData(data)
            .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 20, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(applicationContext).enqueueUniqueWork(
            "spot-payment-$rrn",
            ExistingWorkPolicy.KEEP,
            request
        )
    }
}
