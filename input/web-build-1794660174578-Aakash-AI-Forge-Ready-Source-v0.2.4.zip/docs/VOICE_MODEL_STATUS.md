# Voice model integration status

The Android app currently uses Android `TextToSpeech` as a temporary baseline. It is not a voice-cloning engine.

The intended offline runtime is sherpa-onnx, which provides Android/Kotlin TTS APIs and can run compatible ONNX models locally. The runtime requires its Android native libraries and a model package containing the correct model graph, tokens, lexicon/phoneme resources and configuration. A random `.onnx` file cannot be loaded safely as a voice model.

Before wiring the runtime into the production UI, the project needs:

1. A selected model architecture and compatible training/export recipe.
2. The user's consented, transcript-aligned Nepali recordings.
3. A trained model exported to a sherpa-onnx-supported format.
4. A model package and licence review.
5. Android arm64 runtime integration and on-device memory/latency tests.
6. Audio export validation (WAV first; MP3 requires a real MP3 encoder, not a renamed WAV file).

No model is bundled in this source. This is deliberate: shipping an unrelated voice or a fake placeholder would not meet the personal-voice requirement.


## MP3 export (v0.2.4)

The Library now offers an MP3 export action for generated PCM WAV and recorded AAC/M4A. WAV is parsed as 16-bit PCM; M4A is decoded with Android MediaExtractor/MediaCodec before LAME encoding. Output is 128 kbps MP3 and is written through the Android document picker. This feature is separate from voice cloning. Validate conversion and playback on the target Android 17 device; the selected TAndroidLame fork reports a 16 KB page-alignment fix; still verify the actual APK on the target device.
