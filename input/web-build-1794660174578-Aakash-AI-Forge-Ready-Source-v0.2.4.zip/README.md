# Aakash AI — Android source v0.2.4

A native Kotlin + Jetpack Compose Android voice studio. The project keeps the original blue/white design, animated navigation and vector launcher icon.

## Implemented in v0.2.4

- Home, Create, My Voice, Library and Settings screens.
- Animated navigation transitions.
- Microphone recording to M4A/AAC in app-private storage.
- A transcript editor for each new voice sample; the matching UTF-8 `.txt` transcript is saved beside the audio.
- Dataset ZIP export containing `audio/`, `transcripts/`, `metadata.tsv` and a README.
- `tools/prepare_dataset.py` to validate the exported manifest and convert M4A files to mono 22.05 kHz WAV for a later training workflow (requires ffmpeg).
- On-device Android system TTS generation, requesting Nepali (Nepal) first and using an English system voice only if Nepali is unavailable.
- Generated WAV and recorded M4A files appear in the Library and can be exported using Android's document picker.
- MP3 conversion/export from the Library for 16-bit PCM WAV and AAC/M4A files, using an on-device LAME encoder at 128 kbps. The converted MP3 is saved through Android's document picker; original source files remain unchanged.
- Custom blue/white adaptive vector app icon.
- Java and Kotlin target JVM 17.

## What is not yet delivered

This is **not yet the finished personal Nepali voice-cloning product**. No Aakash voice model is included or trained. The system TTS engine is a fallback voice and does not imitate the user's recordings. The project does not yet include the sherpa-onnx native runtime integration, a compatible trained Nepali model, or offline personal-voice inference. MP3 export is now implemented for supported WAV/M4A files; it is an audio-format conversion and does not change the voice identity.

A personal voice model needs recordings from the speaker, accurate matching transcripts, model training, and a model format supported by the Android inference runtime. A dataset export is now implemented, but the training run itself cannot be performed without the user's actual samples and suitable training compute. A phone-only build is not sufficient to train a high-quality neural voice model.

## Prepare a dataset

1. In My Voice, enter the exact Nepali text you will read.
2. Record the sample in a quiet room, reading that text exactly.
3. Repeat with varied sentences and natural delivery. Do not reuse a transcript that does not match the audio.
4. Tap **Export voice dataset ZIP** and save the ZIP.
5. On a Linux/Colab environment with Python and ffmpeg, run:

   ```bash
   python tools/prepare_dataset.py AakashAI-voice-dataset.zip --output aakash_training_data
   ```

6. Review `metadata.csv` and listen to the WAV files. Correct any transcript mismatch before training.

The script only prepares data. It does not train a voice model or claim a model is ready.

## Build with AndroidForge

Import the project root containing `settings.gradle.kts`. Use JDK 17 and Android SDK 35. The GitHub Actions workflow is `.github/workflows/build-apk.yml`.

The ZIP has not been compiled or device-tested in this environment. Run AndroidForge/GitHub Actions and share the complete build log if compilation fails. The MP3 encoder is pulled from JitPack as `com.github.kaushik-naik:TAndroidLame:a485052f28`; the upstream project documents its LAME wrapper API and marks the library GPL-3.0. If redistributing Aakash AI, review and comply with the dependency license/source obligations. Also verify the native encoder on your Android 17 device: upstream has an open report about 16 KB page alignment, so this package must be runtime-tested on that phone before calling MP3 export production-ready.

## Offline behaviour

Recording and local file management work without Internet. Android system TTS may work offline only when the selected system engine has a downloaded offline Nepali voice. The future personal neural voice will be offline only after a compatible model and inference runtime are installed on the device.

## Privacy

Recordings and generated audio are stored in app-private storage unless explicitly exported by the user. Dataset ZIPs contain voice biometrics and should be treated as private files.
