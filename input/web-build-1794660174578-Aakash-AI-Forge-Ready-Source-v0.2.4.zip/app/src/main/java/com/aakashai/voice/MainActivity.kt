package com.aakashai.voice

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File
import java.util.UUID
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private val Blue = Color(0xFF2563EB)
private val DeepBlue = Color(0xFF1746B5)
private val PaleBlue = Color(0xFFEFF6FF)
private val Ink = Color(0xFF14213D)
private val Muted = Color(0xFF718096)
private val Canvas = Color(0xFFF6F8FC)
private val Border = Color(0xFFE6ECF5)
private val Green = Color(0xFF16A36A)

class MainActivity : ComponentActivity() {
    private var speechEngine: TextToSpeech? = null
    private var speechReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speechEngine = TextToSpeech(this) { result ->
            speechReady = result == TextToSpeech.SUCCESS
            if (speechReady) {
                val engine = speechEngine
                val languageResult = engine?.setLanguage(Locale("ne", "NP"))
                if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine?.setLanguage(Locale("en", "US"))
                }
            }
        }
        setContent {
            AakashTheme {
                AakashApp(onGenerateSpeech = { text, onStatus ->
                    val engine = speechEngine
                    if (!speechReady || engine == null) {
                        onStatus("Android speech engine is not ready. Check that a Nepali voice is installed in your phone's Text-to-speech settings.")
                    } else {
                        val output = File(filesDir, "aakash_speech_${System.currentTimeMillis()}.wav")
                        val utteranceId = UUID.randomUUID().toString()
                        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(id: String?) { runOnUiThread { onStatus("Generating speech…") } }
                            override fun onDone(id: String?) { runOnUiThread { onStatus("Speech saved: ${output.name}. This uses the phone's installed system voice, not your cloned voice.") } }
                            @Deprecated("Deprecated in Java")
                            override fun onError(id: String?) { runOnUiThread { onStatus("Speech generation failed. Try another installed voice.") } }
                            override fun onError(id: String?, errorCode: Int) { runOnUiThread { onStatus("Speech generation failed (code $errorCode).") } }
                        })
                        val params = hashMapOf(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID to utteranceId)
                        val result = engine.synthesizeToFile(text, params, output.absolutePath)
                        if (result != TextToSpeech.SUCCESS) onStatus("Could not start speech generation. Check the installed speech engine.")
                    }
                })
            }
        }
    }

    override fun onDestroy() {
        speechEngine?.stop()
        speechEngine?.shutdown()
        speechEngine = null
        super.onDestroy()
    }
}

@Composable
private fun AakashTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            onPrimary = Color.White,
            primaryContainer = PaleBlue,
            onPrimaryContainer = DeepBlue,
            secondary = Color(0xFF5B8DEF),
            background = Canvas,
            surface = Color.White,
            onSurface = Ink,
            onSurfaceVariant = Muted,
            outline = Border
        ),
        typography = Typography(),
        content = content
    )
}

private enum class Tab(val label: String) {
    HOME("Home"), CREATE("Create"), VOICES("My Voice"), LIBRARY("Library"), SETTINGS("Settings")
}

private data class RecordingItem(val file: File, val createdAt: Long)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AakashApp(onGenerateSpeech: (String, (String) -> Unit) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedTab by remember { mutableStateOf(Tab.HOME) }
    var script by remember { mutableStateOf("नमस्कार! Aakash AI मा तपाईंलाई स्वागत छ।") }
    var isRecording by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Your personal voice studio is ready.") }
    var latestFile by remember { mutableStateOf<File?>(null) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var recordings by remember { mutableStateOf(listOf<RecordingItem>()) }
    var sampleTranscript by remember { mutableStateOf("नमस्कार! मेरो नाम आकाश हो।") }

    fun refreshRecordings() {
        recordings = context.filesDir.listFiles()
            ?.filter { it.isFile && (it.name.endsWith(".m4a") || it.name.endsWith(".wav")) }
            ?.sortedByDescending { it.lastModified() }
            ?.map { RecordingItem(it, it.lastModified()) } ?: emptyList()
    }
    LaunchedEffect(Unit) { refreshRecordings() }

    fun startRecording() {
        try {
            val file = File(context.filesDir, "aakash_${System.currentTimeMillis()}.m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioEncodingBitRate(128000)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            latestFile = file
            isRecording = true
            status = "Recording in progress… speak clearly and naturally."
        } catch (e: Exception) {
            status = "Could not start recording: ${e.localizedMessage ?: "Unknown error"}"
        }
    }

    fun stopRecording() {
        try {
            recorder?.stop()
            recorder?.release()
            recorder = null
            isRecording = false
            latestFile?.let { audio ->
                val transcriptFile = File(audio.parentFile, audio.nameWithoutExtension + ".txt")
                if (sampleTranscript.isNotBlank()) transcriptFile.writeText(sampleTranscript.trim(), Charsets.UTF_8)
            }
            refreshRecordings()
            status = if (sampleTranscript.isNotBlank()) "Recording and transcript saved. This sample is ready for dataset export." else "Recording saved. Add its exact transcript before using it for training."
        } catch (_: Exception) {
            isRecording = false
            recorder?.release()
            recorder = null
            status = "Recording was too short or could not be saved. Try again."
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRecording() else status = "Microphone permission is required to record your voice."
    }

    var filePendingExport by remember { mutableStateOf<File?>(null) }
    var filePendingMp3 by remember { mutableStateOf<File?>(null) }
    val audioExport = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/*")
    ) { uri ->
        val source = filePendingExport
        if (uri != null && source != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output -> source.inputStream().use { it.copyTo(output) } }
                status = "Audio exported: ${source.name}"
            } catch (e: Exception) {
                status = "Audio export failed: ${e.localizedMessage ?: "storage error"}"
            }
        }
        filePendingExport = null
    }

    val mp3Export = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/mpeg")
    ) { uri ->
        val source = filePendingMp3
        if (uri != null && source != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    source.inputStream().use { it.copyTo(output) }
                } ?: error("Could not open the selected destination.")
                status = "MP3 exported successfully: ${source.name}"
            } catch (e: Exception) {
                status = "MP3 export failed: ${e.localizedMessage ?: "storage error"}"
            }
        }
        filePendingMp3?.delete()
        filePendingMp3 = null
    }

    val datasetExport = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    ZipOutputStream(output).use { zip ->
                        val manifest = StringBuilder("audio\ttranscript\n")
                        recordings.filter { it.file.extension.lowercase() == "m4a" }.forEach { item ->
                            val transcript = File(item.file.parentFile, item.file.nameWithoutExtension + ".txt")
                            zip.putNextEntry(ZipEntry("audio/${item.file.name}"))
                            item.file.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                            val text = if (transcript.exists()) transcript.readText(Charsets.UTF_8).replace("\t", " ").replace("\n", " ") else ""
                            if (transcript.exists()) {
                                zip.putNextEntry(ZipEntry("transcripts/${transcript.name}"))
                                transcript.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                            manifest.append("audio/").append(item.file.name).append("\t").append(text).append("\n")
                        }
                        zip.putNextEntry(ZipEntry("metadata.tsv"))
                        zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                        zip.putNextEntry(ZipEntry("README.txt"))
                        zip.write("Aakash AI voice dataset. Each audio recording should have an exact matching transcript. Record in a quiet room with consistent microphone distance. Review transcripts before model training.".toByteArray())
                        zip.closeEntry()
                    }
                }
                status = "Voice dataset exported. Keep this ZIP safe; it contains your voice recordings."
            } catch (e: Exception) {
                status = "Dataset export failed: ${e.localizedMessage ?: "storage error"}"
            }
        }
    }

    Scaffold(
        containerColor = Canvas,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                        Box(
                            Modifier.size(39.dp).clip(RoundedCornerShape(13.dp))
                                .background(Brush.linearGradient(listOf(Blue, DeepBlue))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = Color.White)
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                            Text("Aakash AI", fontWeight = FontWeight.ExtraBold, color = Ink)
                            Text("NEPALI VOICE STUDIO", style = MaterialTheme.typography.labelSmall, color = Muted)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { selectedTab = Tab.SETTINGS }) {
                        Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Ink)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                Tab.values().forEach { tab ->
                    val icon = when (tab) {
                        Tab.HOME -> Icons.Rounded.Home
                        Tab.CREATE -> Icons.Rounded.AutoAwesome
                        Tab.VOICES -> Icons.Rounded.RecordVoiceOver
                        Tab.LIBRARY -> Icons.Rounded.LibraryMusic
                        Tab.SETTINGS -> Icons.Rounded.Settings
                    }
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(icon, contentDescription = tab.label) },
                        label = { Text(tab.label, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Blue,
                            selectedTextColor = Blue,
                            indicatorColor = PaleBlue,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        AnimatedContent(
            targetState = selectedTab,
            modifier = Modifier.padding(padding).fillMaxSize(),
            transitionSpec = {
                (fadeIn(tween(220)) + slideInHorizontally(
                    animationSpec = tween(280, easing = FastOutSlowInEasing),
                    initialOffsetX = { it / 14 }
                )).togetherWith(
                    fadeOut(tween(140)) + slideOutHorizontally(
                        animationSpec = tween(220, easing = FastOutSlowInEasing),
                        targetOffsetX = { -it / 18 }
                    )
                ).using(SizeTransform(clip = false))
            },
            label = "main_navigation"
        ) { tab ->
            when (tab) {
                Tab.HOME -> HomeScreen(
                    onCreate = { selectedTab = Tab.CREATE },
                    onRecord = { selectedTab = Tab.VOICES },
                    recordingCount = recordings.size,
                    status = status
                )
                Tab.CREATE -> CreateScreen(
                    script = script,
                    onScriptChange = { script = it },
                    onGenerate = { onGenerateSpeech(script) { message -> status = message; refreshRecordings() } }
                )
                Tab.VOICES -> VoiceScreen(
                    isRecording = isRecording,
                    status = status,
                    latestFile = latestFile,
                    transcript = sampleTranscript,
                    onTranscriptChange = { sampleTranscript = it },
                    onExportDataset = { datasetExport.launch("AakashAI-voice-dataset.zip") },
                    onRecord = {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (granted) startRecording() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onStop = { stopRecording() },
                    onPlay = { file ->
                        try {
                            player?.release()
                            player = MediaPlayer().apply {
                                setDataSource(file.absolutePath)
                                prepare()
                                start()
                            }
                            status = "Playing recording."
                        } catch (_: Exception) { status = "Unable to play this recording." }
                    }
                )
                Tab.LIBRARY -> LibraryScreen(
                    recordings = recordings,
                    onExport = { file -> filePendingExport = file; audioExport.launch(file.name) },
                    onExportMp3 = { source ->
                        status = "Converting ${source.name} to MP3…"
                        Thread {
                            val converted = File(context.cacheDir, "${source.nameWithoutExtension}_${System.currentTimeMillis()}.mp3")
                            try {
                                Mp3Converter.convert(source, converted, 128)
                                Handler(Looper.getMainLooper()).post {
                                    filePendingMp3 = converted
                                    status = "MP3 is ready. Choose where to save it."
                                    mp3Export.launch("${source.nameWithoutExtension}.mp3")
                                }
                            } catch (e: Exception) {
                                converted.delete()
                                Handler(Looper.getMainLooper()).post {
                                    status = "MP3 conversion failed: ${e.localizedMessage ?: "unsupported audio"}"
                                }
                            }
                        }.start()
                    },
                    onPlay = { file ->
                        try {
                            player?.release()
                            player = MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); start() }
                            status = "Playing recording."
                        } catch (_: Exception) { status = "Unable to play this recording." }
                    }
                )
                Tab.SETTINGS -> SettingsScreen()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try { recorder?.release() } catch (_: Exception) {}
            try { player?.release() } catch (_: Exception) {}
        }
    }
}

@Composable
private fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Canvas).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = content
    )
}

@Composable
private fun HomeScreen(onCreate: () -> Unit, onRecord: () -> Unit, recordingCount: Int, status: String) {
    PageColumn {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Good day 👋", style = MaterialTheme.typography.titleMedium, color = Muted)
            Text("Create something\nwith your voice.", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold, color = Ink)
        }
        Card(
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                Modifier.background(Brush.linearGradient(listOf(Color(0xFF3478F6), Color(0xFF1746B5))))
                    .padding(21.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Color.White.copy(alpha = .18f), shape = CircleShape) {
                            Icon(Icons.Rounded.Waves, null, tint = Color.White, modifier = Modifier.padding(10.dp).size(22.dp))
                        }
                        Spacer(Modifier.width(9.dp))
                        Text("YOUR PERSONAL VOICE", color = Color.White.copy(alpha = .9f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                    Text("Your words.\nYour voice. Your AI.", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("Build and use your own Nepali voice model.", color = Color.White.copy(alpha = .85f))
                    Button(
                        onClick = onCreate,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepBlue),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Create speech", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(7.dp))
                        Icon(Icons.Rounded.ArrowForward, null)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("My recordings", recordingCount.toString(), Icons.Rounded.Mic, Modifier.weight(1f))
            StatCard("Voice model", "Not ready", Icons.Rounded.RecordVoiceOver, Modifier.weight(1f))
        }
        SectionTitle("Quick actions")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile("Record voice", "Train your voice", Icons.Rounded.Mic, onRecord, Modifier.weight(1f))
            ActionTile("Write a script", "Turn text to audio", Icons.Rounded.EditNote, onCreate, Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = Blue)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Project status", fontWeight = FontWeight.Bold, color = Ink)
                    Text(status, color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun CreateScreen(script: String, onScriptChange: (String) -> Unit, onGenerate: () -> Unit) {
    PageColumn {
        ScreenHeading("Create speech", "Write or paste your Nepali script.")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.TextFields, null, tint = Blue)
                    Spacer(Modifier.width(8.dp))
                    Text("YOUR SCRIPT", fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text("${script.length} chars", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
                OutlinedTextField(
                    value = script,
                    onValueChange = onScriptChange,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 190.dp),
                    placeholder = { Text("यहाँ नेपाली वा English text लेख्नुहोस्…") },
                    shape = RoundedCornerShape(15.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Blue,
                        unfocusedBorderColor = Border
                    )
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AssistChip(onClick = { onScriptChange(script + "\nनमस्कार, तपाईंलाई स्वागत छ।") }, label = { Text("Add sample") })
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { onScriptChange("") }) { Text("Clear") }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = PaleBlue), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.RecordVoiceOver, null, tint = Blue)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Selected voice", color = DeepBlue, fontWeight = FontWeight.Bold)
                    Text("Phone system voice for now • personal voice cloning is not yet installed", color = DeepBlue, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Button(
            onClick = onGenerate,
            enabled = script.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Rounded.AutoAwesome, null)
            Spacer(Modifier.width(9.dp))
            Text("Generate audio", fontWeight = FontWeight.Bold)
        }
        Text("This first generator uses your Android phone’s installed TTS voice and may require a downloaded Nepali voice. It does not imitate your recorded voice and offline support depends on that engine.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun VoiceScreen(
    isRecording: Boolean,
    status: String,
    latestFile: File?,
    transcript: String,
    onTranscriptChange: (String) -> Unit,
    onExportDataset: () -> Unit,
    onRecord: () -> Unit,
    onStop: () -> Unit,
    onPlay: (File) -> Unit
) {
    PageColumn {
        ScreenHeading("My voice", "Record clean samples to train your voice.")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("EXACT RECORDING TRANSCRIPT", color = Ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                OutlinedTextField(
                    value = transcript,
                    onValueChange = onTranscriptChange,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                    placeholder = { Text("रेकर्ड गर्दा बोल्ने वाक्य यहाँ लेख्नुहोस्…") },
                    shape = RoundedCornerShape(14.dp)
                )
                Text("Read this text exactly as written, then tap Start recording. A transcript file will be saved beside the audio.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.size(112.dp).clip(CircleShape).background(PaleBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (isRecording) Icons.Rounded.GraphicEq else Icons.Rounded.Mic, null, tint = Blue, modifier = Modifier.size(49.dp))
                }
                Text(if (isRecording) "Recording your voice…" else "Voice recording studio", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                Text(if (isRecording) "Read the text naturally. Avoid rushing." else "Use a quiet room and keep the phone at a steady distance.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                AnimatedVisibility(visible = isRecording) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Blue)
                }
                Button(
                    onClick = if (isRecording) onStop else onRecord,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = if (isRecording) ButtonDefaults.buttonColors(containerColor = Color(0xFFDC3545)) else ButtonDefaults.buttonColors()
                ) {
                    Icon(if (isRecording) Icons.Rounded.Stop else Icons.Rounded.FiberManualRecord, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isRecording) "Stop recording" else "Start recording")
                }
                Text(status, color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        SectionTitle("Recording checklist")
        ChecklistRow("Quiet room", "Avoid fans, traffic and background music")
        ChecklistRow("Consistent distance", "Keep the microphone in the same position")
        ChecklistRow("Natural delivery", "Speak clearly, not like a robot")
        latestFile?.let {
            OutlinedButton(onClick = { onPlay(it) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Play latest recording")
            }
        }
        OutlinedButton(onClick = onExportDataset, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.FolderZip, null); Spacer(Modifier.width(8.dp)); Text("Export voice dataset ZIP")
        }
        Text("Dataset ZIP includes your audio, matching transcript files, and a TSV manifest. It is the input package needed for voice-model training. Keep it private.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun LibraryScreen(recordings: List<RecordingItem>, onExport: (File) -> Unit, onExportMp3: (File) -> Unit, onPlay: (File) -> Unit) {
    PageColumn {
        ScreenHeading("Audio library", "Your recordings saved on this device.")
        if (recordings.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(25.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Icon(Icons.Rounded.LibraryMusic, null, tint = Blue, modifier = Modifier.size(42.dp))
                    Text("No recordings yet", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Your saved voice recordings will appear here.", color = Muted)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(recordings) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = PaleBlue, shape = RoundedCornerShape(12.dp)) {
                                Icon(Icons.Rounded.AudioFile, null, tint = Blue, modifier = Modifier.padding(11.dp))
                            }
                            Spacer(Modifier.width(11.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Ink, fontWeight = FontWeight.SemiBold)
                                Text(SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date(item.createdAt)), color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { onExport(item.file) }) {
                                Icon(Icons.Rounded.FileDownload, contentDescription = "Export original audio", tint = Blue)
                            }
                            IconButton(onClick = { onExportMp3(item.file) }) {
                                Icon(Icons.Rounded.MusicNote, contentDescription = "Convert and export MP3", tint = DeepBlue)
                            }
                            IconButton(onClick = { onPlay(item.file) }) {
                                Icon(Icons.Rounded.PlayCircle, null, tint = Blue, modifier = Modifier.size(29.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    PageColumn {
        ScreenHeading("Settings", "Personalise your Aakash AI studio.")
        SettingsRow(Icons.Rounded.Palette, "Appearance", "Blue & white theme", "Active")
        SettingsRow(Icons.Rounded.WifiOff, "Offline mode", "On-device generation", "Model pending")
        SettingsRow(Icons.Rounded.Storage, "Storage", "Recordings saved on this phone", "Local")
        SettingsRow(Icons.Rounded.Security, "Privacy", "Your recordings stay in app storage", "Private")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Aakash AI", fontWeight = FontWeight.ExtraBold, color = Ink)
                Text("Version 0.2.4 • Android voice studio", color = Muted, style = MaterialTheme.typography.bodySmall)
                Text("Independent Nepali voice project", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ScreenHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Ink)
        Text(subtitle, color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = Blue)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text(title, style = MaterialTheme.typography.bodySmall, color = Muted)
        }
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Surface(color = PaleBlue, shape = RoundedCornerShape(12.dp)) {
                Icon(icon, null, tint = Blue, modifier = Modifier.padding(9.dp))
            }
            Text(title, color = Ink, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ChecklistRow(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
        Icon(Icons.Rounded.CheckCircle, null, tint = Green)
        Column {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SettingsRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            Text(value, color = Blue, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
    }
}
