# Third-party notices

## TAndroidLame

Aakash AI v0.2.4 uses `com.github.kaushik-naik:TAndroidLame:a485052f28` for on-device MP3 encoding.

- Upstream: https://github.com/kaushik-naik/TAndroidLame
- License stated by upstream: GNU General Public License v3.0 (GPL-3.0-or-later as specified by the upstream project)
- Dependency repository: https://jitpack.io

Review the upstream license and satisfy its source-code and redistribution requirements before distributing a binary build of Aakash AI. The encoder is not a paid API and performs conversion locally on the Android device.
