plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.aakashai.voice"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aakashai.voice"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "0.3.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
}

kotlin {
    jvmToolchain(17)
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    // LAME-based MP3 encoder. GPL-3.0: comply with its redistribution/source obligations.
    implementation("com.github.kaushik-naik:TAndroidLame:a485052f28")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
