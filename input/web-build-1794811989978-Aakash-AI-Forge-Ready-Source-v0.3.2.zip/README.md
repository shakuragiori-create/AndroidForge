# Aakash AI — Android source v0.3.2

A native Kotlin + Jetpack Compose Nepali voice studio with a personal voice-reference workflow, a server-backed Nepali voice-cloning integration, and local MP3 export.

## Implemented in v0.3.2

- Blue/white Compose UI, animated navigation, and a custom Aakash AI waveform logo used as the launcher icon and in-app brand mark.
- Local microphone recording to M4A/AAC with a matching UTF-8 transcript.
- My Voice recordings can be selected as the reference voice in Create.
- Create screen accepts Nepali, English, and mixed text, and submits the selected reference recording + exact transcript + target text to the configured Aakash AI clone server.
- `CloneApiClient` uses HTTPS multipart upload, bounded connection/read timeouts, server error handling, and verifies that an audio response was returned.
- Generated WAV is saved in app-private storage and appears in Library.
- Library supports playback, original audio export, and MP3 conversion/export.
- Settings stores the server URL and has a health check.
- The server code and a phone-friendly Google Colab notebook are included in `backend/`.
- Java/Kotlin JVM target 17.

## Voice-clone architecture

The Android app is the client. The included FastAPI backend loads the open Nepali **Swar** checkpoint (`Aarjan/swar`) using the official Swar enrollment and synthesis pipeline on a Colab GPU runtime. The app sends a voice reference clip, its exact transcript, and the requested text. The backend returns a WAV file. MP3 conversion is performed locally by the existing LAME-based encoder.

This is a reference-conditioned clone, not a newly trained personal checkpoint. It needs a running GPU server and Internet connection. Free Colab GPU availability and session duration are not guaranteed. Offline neural cloning is not included yet; only recording, playback, file storage, and MP3 conversion are local.

## Start the clone server

See `backend/README.md`. In brief: open `backend/AakashAI_Clone_Server_Colab.ipynb` in Colab on your phone, upload `Aakash-AI-Clone-Backend.zip`, run the cells, copy the temporary HTTPS URL into Aakash AI → Settings, and test the connection.

## Record your voice

1. Open My Voice.
2. Enter the exact words you will say.
3. Record 20–30 seconds in a quiet room, speaking naturally.
4. Stop and play the recording to check it.
5. Open Create and select the recording.
6. Enter the text to synthesize and tap Generate with my cloned voice.
7. Open Library. Use the MP3 icon to convert and save the generated WAV as MP3.

## Build with AndroidForge

Import the project root containing `settings.gradle.kts`. Use JDK 17 and Android SDK 35. `.github/workflows/build-apk.yml` builds the debug APK.

**Build status:** This package has not been compiled with Android SDK/Gradle or installed on a physical phone in this environment. Do not treat it as device-verified until AndroidForge/GitHub Actions completes successfully and the generated WAV/MP3 are tested on your phone. The code and Python files are syntax/structure checked where possible, but the complete app + Colab model path needs an end-to-end test.

## Privacy and safety

Recordings and generated files are app-private unless exported. When Generate is tapped, the selected reference recording, transcript, and target text are sent to the HTTPS server configured by the user. The included Colab tunnel is temporary and should not be shared. Only clone a voice you own or have permission to use.

## Third-party model

Swar is provided by Naamche Labs. Code is MIT; model weights are CC BY-SA 4.0. See `THIRD_PARTY_NOTICES.md` and the upstream model card. The model weights are downloaded by the backend, not included in this Android source ZIP.
