# The Spot Payment Speaker — Android source 1.2.1

## Spot-branded UI and launcher refresh

This update uses the supplied RestaurantPro Manager plugin ZIP as the branding source.

- Rebuilt the Android home screen with The Spot's black, yellow, brown and cream palette.
- Uses the plugin's original transparent `the-spot-logo.png` in the app header.
- Uses the plugin's `spot-favicon.png` for legacy launcher icon assets.
- Adds Android adaptive and round launcher icon resources for Android 8.0+.
- Keeps the 1.2.0 payment notification rules, local switches, secure device-key storage, Spot connection workflow, diagnostics and offline-first speech logic.
- Improves spacing, section cards, field styling, switch styling and button hierarchy for a more native Spot-branded experience.
- Keeps the Spot website popup and PHP plugin untouched.

## Branding palette

- Spot yellow: `#F5C300`
- Black: `#111111`
- Brown: `#6B3A2A`
- Cream: `#F5EFD6`

## Existing 1.2.0 behaviour retained

- Fonepay announcement from successful `SBL_Alert` / `Transaction success` / `Fonepay QR` notifications.
- eSewa notification detection and local diagnostic samples.
- Custom app/title/success-keyword matching rule with `{amount}` and `{rupees}` placeholders.
- Separate local switches for Payment Speaker, Fonepay, eSewa and Custom.
- Local duplicate protection.
- Spot master announcement gate cached after a successful online status check.
- WorkManager used for Fonepay record forwarding, not as the trigger for local speech.
- Device key protected using Android Keystore AES/GCM.

## Integration and operational notes

The current Spot endpoint is designed for the existing Fonepay/SBL notification format. eSewa and custom notifications are announced locally and are not synced to Spot payment history by this Android source version. The eSewa notification format must be validated against a real payment notification before production use.

Offline announcements require the phone to be powered on, Notification Access to be enabled, the local and cached Spot master settings to permit announcements, and an offline-capable Nepali `ne-NP` TTS voice to be installed. Fonepay records sync when connectivity returns.

## Build

- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.20
- JDK: 17
- Android SDK Platform: 35
- Build variant: Auto
- Force NDK Install: unchecked

Open the `TheSpotPaymentSpeaker` folder in Android Studio or upload the project to the Android build service. This source archive has been structurally checked, but an Android SDK build and on-device icon/notification/voice test have not been run in this environment.
