package com.thespot.paymentspeaker

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.content.res.ColorStateList
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val ink = Color.rgb(17, 17, 17)
    private val yellow = Color.rgb(245, 195, 0)
    private val brown = Color.rgb(107, 58, 42)
    private val cream = Color.rgb(245, 239, 214)
    private val muted = Color.rgb(112, 105, 91)
    private val paper = Color.WHITE

    private lateinit var urlInput: EditText
    private lateinit var keyInput: EditText
    private lateinit var permissionStatus: TextView
    private lateinit var connectionStatus: TextView
    private lateinit var diagnosticsView: TextView
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ink
        window.navigationBarColor = cream
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        buildUi()
        refreshPermissionStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(cream)
            clipToPadding = false
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
        }

        // Branded hero, using the transparent logo supplied by the Spot plugin.
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            background = rounded(ink, 26)
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.the_spot_logo)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "The Spot Fast Food and Tea"
        }
        hero.addView(logo, LinearLayout.LayoutParams(-1, dp(94)))
        hero.addView(TextView(this).apply {
            text = "PAYMENT SPEAKER"
            textSize = 19f
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(3))
        })
        hero.addView(TextView(this).apply {
            text = "LOCAL-FIRST  •  NEPALI VOICE"
            textSize = 10f
            letterSpacing = 0.13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(yellow)
            setPadding(0, dp(2), 0, dp(12))
        })
        hero.addView(TextView(this).apply {
            text = "Hear successful payments instantly — even when this phone is offline."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(235, 231, 218))
            setLineSpacing(dp(2).toFloat(), 1f)
        })
        content.addView(hero, matchWrap())

        // Compact quick-status strip.
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            background = rounded(paper, 18)
        }
        quick.addView(TextView(this).apply {
            text = "●"
            textSize = 13f
            setTextColor(Color.rgb(36, 151, 84))
        })
        quick.addView(TextView(this).apply {
            text = "  ON-DEVICE ANNOUNCEMENTS"
            textSize = 11f
            letterSpacing = 0.04f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        quick.addView(TextView(this).apply {
            text = "OFFLINE READY*"
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(brown)
            background = rounded(cream, 30)
            setPadding(dp(9), dp(6), dp(9), dp(6))
        })
        val quickLp = matchWrap().apply { topMargin = dp(12) }
        content.addView(quick, quickLp)

        sectionCard(content, "ANNOUNCEMENT CONTROLS", "Choose which payment notifications this phone should speak.") { card ->
            addSwitch(card, "Payment Speaker", PaymentPrefs.master(this), PaymentPrefs::setMaster,
                "Main local switch. Turn OFF to stop every announcement.")
            addDivider(card)
            addSwitch(card, "Fonepay", PaymentPrefs.fonepay(this), PaymentPrefs::setFonepay,
                "Successful SBL_Alert · Fonepay QR notifications.")
            addDivider(card)
            addSwitch(card, "eSewa", PaymentPrefs.esewa(this), PaymentPrefs::setEsewa,
                "Incoming-payment notifications detected from the eSewa app.")
            addDivider(card)
            addSwitch(card, "Custom announcements", PaymentPrefs.custom(this), PaymentPrefs::setCustom,
                "Use a matching rule for another payment notification app.")
        }

        sectionCard(content, "CUSTOM NOTIFICATION RULE", "Set the notification pattern and the Nepali message to speak.") { card ->
            val packageInput = field("App name or package contains", PaymentPrefs.customPackage(this))
            val titleRuleInput = field("Notification title contains (optional)", PaymentPrefs.customTitle(this))
            val keywordInput = field("Success keyword in message (required)", PaymentPrefs.customKeyword(this))
            val templateInput = field("Announcement text; use {amount}", PaymentPrefs.customTemplate(this))
            card.addView(packageInput, fieldLp())
            card.addView(titleRuleInput, fieldLp())
            card.addView(keywordInput, fieldLp())
            card.addView(templateInput, fieldLp())
            card.addView(actionButton("SAVE CUSTOM RULE") {
                PaymentPrefs.saveCustom(this, packageInput.text.toString(), titleRuleInput.text.toString(),
                    keywordInput.text.toString(), templateInput.text.toString())
                Toast.makeText(this, "Custom notification rule saved on this phone.", Toast.LENGTH_SHORT).show()
            }, buttonLp())
            card.addView(note("A rule needs a specific success keyword and a recognised amount (Rs, NPR or रु)."))
        }

        sectionCard(content, "SPOT CONNECTION", "Link this phone to the staff device registered in your Spot Panel.") { card ->
            urlInput = field("Spot website URL (https://...)", SpotConfig.baseUrl(this))
            keyInput = field("Device key from Spot Settings", "")
            keyInput.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            card.addView(fieldLabel("SPOT WEBSITE"))
            card.addView(urlInput, fieldLp())
            card.addView(fieldLabel("DEVICE KEY"))
            card.addView(keyInput, fieldLp())
            card.addView(actionButton("SAVE SPOT CONNECTION") { saveConnection() }, buttonLp())
            connectionStatus = statusText("Connection not checked")
            card.addView(connectionStatus, fieldLp())
            card.addView(actionButton("CHECK CONNECTION") { checkConnection() }, buttonLp())
        }

        sectionCard(content, "PHONE SETUP", "Android must allow The Spot to read payment-app notifications.") { card ->
            permissionStatus = statusText("Notification Access: checking…")
            card.addView(permissionStatus, fieldLp())
            card.addView(actionButton("ENABLE NOTIFICATION ACCESS") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }, buttonLp())
            card.addView(actionButton("TEST NEPALI VOICE") {
                executor.execute {
                    val ok = NepaliSpeech.speakBlocking(this, "पाँच सय रुपैयाँ भुक्तानी प्राप्त भयो।")
                    runOnUiThread {
                        Toast.makeText(this,
                            if (ok) "Nepali voice test completed." else "Nepali voice unavailable. Install offline Nepali voice data in your phone's Text-to-Speech settings.",
                            Toast.LENGTH_LONG).show()
                    }
                }
            }, buttonLp())
            card.addView(note("For reliable background listening, allow unrestricted battery use for this app. Offline speech requires an installed offline Nepali voice."))
        }

        sectionCard(content, "eSEWA DIAGNOSTICS", "Captured notification samples help identify the eSewa payment format.") { card ->
            diagnosticsView = statusText("")
            card.addView(diagnosticsView, fieldLp())
            card.addView(actionButton("REFRESH SAMPLES") { refreshDiagnostics() }, buttonLp())
            card.addView(actionButton("CLEAR SAMPLES") {
                PaymentPrefs.clearDiagnostics(this)
                refreshDiagnostics()
            }, buttonLp())
            card.addView(note("Samples are stored locally on this phone. Confirm the real notification format before relying on eSewa announcements."))
        }

        sectionCard(content, "HOW IT WORKS", "Your phone speaks first. Spot sync happens when internet is available.") { card ->
            val steps = listOf(
                "01" to "Assign this phone to the staff account in Spot Settings and copy its device key.",
                "02" to "Save the HTTPS Spot website URL and device key above.",
                "03" to "Enable Android Notification Access for The Spot Payment Listener.",
                "04" to "Turn on the payment sources you want this phone to announce.",
                "05" to "Connect once while online to cache the Spot master announcement setting.",
                "06" to "Announcements run locally. Fonepay payment records sync when internet returns."
            )
            steps.forEachIndexed { index, pair ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.TOP
                    setPadding(0, dp(7), 0, dp(7))
                }
                row.addView(TextView(this).apply {
                    text = pair.first
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setTextColor(ink)
                    background = rounded(yellow, 9)
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                })
                row.addView(TextView(this).apply {
                    text = pair.second
                    textSize = 13f
                    setTextColor(muted)
                    setLineSpacing(dp(2).toFloat(), 1f)
                    setPadding(dp(11), 0, 0, 0)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                card.addView(row)
                if (index != steps.lastIndex) addDivider(card)
            }
        }

        content.addView(TextView(this).apply {
            text = "THE SPOT  •  FAST FOOD AND TEA"
            textSize = 10f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(brown)
            setPadding(0, dp(20), 0, dp(6))
        })
        content.addView(TextView(this).apply {
            text = "Payment Speaker"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(muted)
        })

        scroll.addView(content)
        setContentView(scroll)
        refreshDiagnostics()
    }

    private fun sectionCard(parent: LinearLayout, title: String, subtitle: String, build: (LinearLayout) -> Unit) {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(paper, 20)
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 14f
            letterSpacing = 0.045f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        outer.addView(heading)
        outer.addView(TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(5), 0, dp(12))
        })
        build(outer)
        val lp = matchWrap().apply { topMargin = dp(13) }
        parent.addView(outer, lp)
    }

    private fun addSwitch(parent: LinearLayout, label: String, checked: Boolean,
                          save: (android.content.Context, Boolean) -> Unit, description: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val textColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textColumn.addView(TextView(this).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        })
        textColumn.addView(TextView(this).apply {
            text = description
            textSize = 11f
            setTextColor(muted)
            setPadding(0, dp(3), dp(8), 0)
        })
        row.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply {
            isChecked = checked
            text = ""
            thumbTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(yellow, Color.LTGRAY)
            )
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.rgb(220, 176, 0), Color.rgb(220, 220, 220))
            )
            setOnCheckedChangeListener { _, value -> save(this@MainActivity, value) }
        })
        parent.addView(row, matchWrap())
    }

    private fun addDivider(parent: LinearLayout) {
        val line = View(this).apply { setBackgroundColor(Color.rgb(239, 235, 225)) }
        parent.addView(line, LinearLayout.LayoutParams(-1, dp(1)).apply {
            topMargin = dp(8); bottomMargin = dp(8)
        })
    }

    private fun field(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText
        textSize = 13f
        setText(value)
        setTextColor(ink)
        setHintTextColor(Color.rgb(154, 148, 135))
        setPadding(dp(13), dp(11), dp(13), dp(11))
        background = rounded(Color.rgb(250, 248, 241), 12, Color.rgb(231, 225, 210))
        minHeight = dp(48)
    }

    private fun fieldLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 10f
        letterSpacing = 0.08f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(brown)
        setPadding(dp(2), dp(7), 0, dp(2))
    }

    private fun fieldLp() = LinearLayout.LayoutParams(-1, -2).apply {
        bottomMargin = dp(8)
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        letterSpacing = 0.035f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(ink)
        background = rounded(yellow, 12)
        minHeight = dp(48)
        stateListAnimator = null
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { action() }
    }

    private fun buttonLp() = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(6)
        bottomMargin = dp(5)
    }

    private fun statusText(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(muted)
        setPadding(dp(12), dp(11), dp(12), dp(11))
        background = rounded(Color.rgb(250, 248, 241), 11)
    }

    private fun note(value: String) = TextView(this).apply {
        text = value
        textSize = 11f
        setTextColor(muted)
        setLineSpacing(dp(2).toFloat(), 1f)
        setPadding(dp(2), dp(7), dp(2), dp(2))
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun saveConnection() {
        val base = urlInput.text.toString().trim().trimEnd('/')
        val key = keyInput.text.toString().trim().ifBlank { SpotConfig.deviceKey(this) }
        if (!base.startsWith("https://") || key.isBlank()) {
            Toast.makeText(this, "Enter the HTTPS Spot website URL and device key.", Toast.LENGTH_LONG).show()
            return
        }
        SpotConfig.setBaseUrl(this, base)
        SpotConfig.setDeviceKey(this, key)
        keyInput.setText("")
        Toast.makeText(this, "Spot connection saved securely on this phone.", Toast.LENGTH_SHORT).show()
        checkConnection()
    }

    private fun checkConnection() {
        val base = SpotConfig.baseUrl(this)
        val key = SpotConfig.deviceKey(this)
        if (!base.startsWith("https://") || key.isBlank()) {
            if (::connectionStatus.isInitialized) connectionStatus.text = "Save the Spot URL and device key first."
            return
        }
        connectionStatus.text = "Checking secure connection…"
        executor.execute {
            try {
                val result = SpotApi.status(base, key)
                val body = result.body
                if (result.code in 200..299 && body.optBoolean("ok", false) && body.has("announcement_enabled")) {
                    SpotConfig.setRemoteMaster(this, body.optBoolean("announcement_enabled", false))
                }
                runOnUiThread {
                    connectionStatus.text = if (result.code in 200..299 && body.optBoolean("ok", false)) {
                        if (body.optBoolean("announcement_enabled", false))
                            "CONNECTED  ·  Spot master announcement is ON."
                        else "CONNECTED  ·  Spot master announcement is OFF. Turn it ON in the Spot Profile Menu."
                    } else "Connection failed (${result.code}): ${body.optString("message", "Check the assigned device and key.")}"
                }
            } catch (e: Exception) {
                runOnUiThread { connectionStatus.text = "Connection error: ${e.message ?: "Check internet and HTTPS URL."}" }
            }
        }
    }

    private fun refreshPermissionStatus() {
        val component = ComponentName(this, SpotNotificationListener::class.java)
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(component.flattenToString()) == true
        permissionStatus.text = if (enabled) "NOTIFICATION ACCESS  ·  ENABLED"
        else "NOTIFICATION ACCESS  ·  NOT ENABLED — enable it below."
    }

    private fun refreshDiagnostics() {
        if (!::diagnosticsView.isInitialized) return
        val items = PaymentPrefs.diagnostics(this)
        diagnosticsView.text = if (items.isEmpty())
            "No eSewa notification samples captured yet. When an eSewa notification arrives, its title and message will appear here."
        else items.take(8).joinToString("\n\n────────────\n\n")
    }

    override fun onResume() {
        super.onResume()
        if (::permissionStatus.isInitialized) refreshPermissionStatus()
        if (::connectionStatus.isInitialized && SpotConfig.isConfigured(this)) checkConnection()
        refreshDiagnostics()
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
