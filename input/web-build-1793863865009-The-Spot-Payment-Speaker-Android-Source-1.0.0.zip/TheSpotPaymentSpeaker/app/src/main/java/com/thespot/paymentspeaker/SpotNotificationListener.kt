package com.thespot.paymentspeaker

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class SpotNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val sender = (extras.getCharSequence("android.title") ?: "").toString().trim()
        if (!sender.equals("SBL_Alert", ignoreCase = true)) return
        val body = listOf("android.text", "android.bigText", "android.subText")
            .mapNotNull { extras.getCharSequence(it)?.toString() }.filter { it.isNotBlank() }.distinct().joinToString(" ")
        if (!body.contains("Transaction success", true) || !body.contains("Fonepay QR", true)) return
        if (!Regex("\\bRs\\.?\\s*[0-9][0-9,]*(?:\\.[0-9]{1,2})?", RegexOption.IGNORE_CASE).containsMatchIn(body)) return
        if (!Regex("\\bRRN\\s+[A-Za-z0-9]+", RegexOption.IGNORE_CASE).containsMatchIn(body)) return
        val prefs = getSharedPreferences("spot_payment", MODE_PRIVATE)
        val base = prefs.getString("url", "") ?: ""
        val token = prefs.getString("key", "") ?: ""
        if (!base.startsWith("https://") || token.isBlank()) return
        val identity = "${sbn.packageName}:${sbn.key}:${sbn.postTime}"
        if (prefs.getString("last_forwarded", "") == identity) return
        Thread {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL("$base/wp-json/spot/v1/payment-notification").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 12000; readTimeout = 12000; doOutput = true
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject().put("sender", sender).put("message", body).put("notification_id", identity)
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode in 200..299) prefs.edit().putString("last_forwarded", identity).apply()
            } catch (_: Exception) { /* A later matching notification can retry; do not log SMS content. */ }
            finally { conn?.disconnect() }
        }.start()
    }
}
