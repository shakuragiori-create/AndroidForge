package com.thespot.paymentspeaker

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("spot_payment", MODE_PRIVATE) }
    private lateinit var url: EditText
    private lateinit var key: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 24); setBackgroundColor(0xFFF7F8F7.toInt()) }
        root.addView(TextView(this).apply { text = "THE SPOT"; textSize = 26f; setTextColor(0xFF123B2B.toInt()); gravity = Gravity.CENTER; setPadding(0,0,0,8) })
        root.addView(TextView(this).apply { text = "PAYMENT SPEAKER"; textSize = 16f; gravity = Gravity.CENTER; setPadding(0,0,0,28) })
        url = EditText(this).apply { hint = "Spot website URL (https://...)"; setSingleLine(true); setText(prefs.getString("url", "")) }
        key = EditText(this).apply { hint = "Device webhook key from Spot Settings"; setSingleLine(true); setText(prefs.getString("key", "")) }
        root.addView(url); root.addView(key)
        root.addView(Button(this).apply { text = "Save Spot Connection"; setOnClickListener {
            val base = url.text.toString().trim().trimEnd('/')
            val token = key.text.toString().trim()
            if (!base.startsWith("https://") || token.isBlank()) { Toast.makeText(this@MainActivity, "Enter your HTTPS Spot URL and device key", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            prefs.edit().putString("url", base).putString("key", token).apply()
            Toast.makeText(this@MainActivity, "Spot connection saved", Toast.LENGTH_SHORT).show()
        } })
        root.addView(Button(this).apply { text = "Enable Notification Access"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } })
        root.addView(TextView(this).apply { text = "Enable access for The Spot Payment Listener. Only SBL_Alert payment notifications matching the configured Fonepay QR format are forwarded. Keep this phone connected to the internet."; textSize = 14f; setPadding(0,18,0,0) })
        setContentView(root)
    }
}
