# The Spot Payment Speaker — Android source project

This is an Android Studio project for a small companion listener that forwards only matching SBL_Alert Fonepay QR payment notifications to the existing Spot WordPress REST endpoint. It is not an APK; build/signing requires Android Studio and Android SDK.

## Configure
1. In Spot Panel → Settings → Branding & Business, assign the payment device user and obtain the device webhook key.
2. Install the built APK on Sandesh's Android phone.
3. Enter the HTTPS Spot site URL (domain only, e.g. `https://example.com`) and the webhook key.
4. Tap **Enable Notification Access** and enable **The Spot Payment Listener** in Android Settings.
5. Keep the listener enabled and allow background activity/battery use for this app on the phone.

## Detection scope
- Notification title must be `SBL_Alert`.
- Notification text must contain `Transaction success`, `Fonepay QR`, an `Rs.` amount, and an `RRN` reference.
- Only matching notifications are forwarded. Other notifications are ignored.
- The app does not read the SMS inbox; it observes notifications exposed by Android Notification Access.

## Important integration note
The supplied Spot v3.9.18 plugin currently labels its device credential as a **MacroDroid Webhook Key**. The key is a bearer token for `/wp-json/spot/v1/payment-notification`. The listener sends JSON fields `sender`, `message`, and `notification_id`; the current server parser ignores `notification_id` and deduplicates by RRN. The Android listener forwards the message to the server; Nepali voice playback and the panel's live update still depend on the Spot plugin's client-side implementation and must be validated on the live PWA.

## Build
Open this folder in Android Studio (JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1). Let Gradle sync, then Build → Build Bundle(s) / APK(s) → Build APK(s). For distribution, create and securely retain a release signing key. Do not share the webhook key publicly.

This source has not been built or tested on a physical device in this environment. Android may restrict background execution; test notification access, network delivery, duplicate handling, and Nepali text-to-speech on the target phone before relying on it for payments.
